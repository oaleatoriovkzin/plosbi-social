import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { CSSProperties, FormEvent, KeyboardEvent as ReactKeyboardEvent, RefObject } from 'react';
import {
  Activity, Bell, Bookmark, Check, ChevronDown, Compass, Heart, Home, ImagePlus, LogOut,
  MessageCircle, Moon, MoreHorizontal, Palette, Plus, Search, Send, Settings, ShieldCheck,
  Sparkles, Sun, UserRound, Users, X, Camera, Clock3, Menu, LoaderCircle, ArrowLeft
} from 'lucide-react';
import { hasSupabaseConfig, siteUrl, supabase, friendlyError, initials, timeAgo, resizeImage } from './lib';
import type { Profile, Post, Comment, Message } from './lib';
import { StoriesBar } from './Stories';
import { Capacitor } from '@capacitor/core';
import { App as CapApp } from '@capacitor/app';
import { Browser } from '@capacitor/browser';

type Page = 'feed' | 'explore' | 'messages' | 'profile' | 'servers' | 'settings' | 'wellbeing';
type Theme = 'dark' | 'light';
type Toast = { id: number; text: string; kind?: 'error' | 'success' };

function ButterflyMark({ size = 34 }: { size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden="true" className="butterfly-mark">
    <path d="M30 28C23 9 7 7 5 17c-2 9 9 19 23 18-11 1-18 12-10 19 7 5 14-5 15-19" fill="#0a7cff" stroke="#0a7cff" strokeWidth="1.2"/>
    <path d="M34 28C41 9 57 7 59 17c2 9-9 19-23 18 11 1 18 12 10 19-7 5-14-5-15-19" fill="#0b1220" stroke="#0a7cff" strokeWidth="1.6"/>
    <path d="M32 20v29M31 20c-4-9-10-9-11-8M33 20c4-9 10-9 11-8" stroke="#dbeafe" strokeWidth="2.5" strokeLinecap="round" fill="none"/>
  </svg>;
}

function Avatar({ profile, size = 'md', onClick }: { profile?: Profile | null; size?: 'sm' | 'md' | 'lg' | 'xl'; onClick?: () => void }) {
  return <button type="button" className={`avatar avatar-${size}`} onClick={onClick} aria-label={`Perfil ${profile?.username ?? ''}`}>
    {profile?.avatar_url ? <img src={profile.avatar_url} alt="" /> : <span>{initials(profile)}</span>}
  </button>;
}

function AuthScreen({ notify }: { notify: (text: string, kind?: 'error' | 'success') => void }) {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState(''); const [password, setPassword] = useState('');
  const [username, setUsername] = useState(''); const [displayName, setDisplayName] = useState('');
  const [busy, setBusy] = useState(false); const [showPassword, setShowPassword] = useState(false);
  async function signInWithGitHub() {
    if (!supabase) return notify('Configure VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY e gere novamente o app.', 'error');
    setBusy(true);
    try {
      const native = Capacitor.isNativePlatform();
      const redirectTo = native ? 'com.plosbi.social://auth-callback' : (siteUrl || window.location.origin);
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: 'github',
        options: { redirectTo, skipBrowserRedirect: native }
      });
      if (error) throw error;
      if (native && data?.url) { await Browser.open({ url: data.url }); setBusy(false); }
    } catch (error) {
      notify(friendlyError(error), 'error');
      setBusy(false);
    }
  }
  async function submit(e: FormEvent) {
    e.preventDefault(); if (!supabase) return notify('Configure VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY no arquivo .env.', 'error');
    if (password.length < 8) return notify('A senha precisa ter pelo menos 8 caracteres.', 'error');
    if (mode === 'signup' && !/^[a-z0-9._]{3,24}$/.test(username.trim().toLowerCase())) return notify('Use um @ com 3–24 letras minúsculas, números, ponto ou sublinhado.', 'error');
    setBusy(true);
    try {
      if (mode === 'signup') {
        const { data, error } = await supabase.auth.signUp({ email: email.trim().toLowerCase(), password, options: { emailRedirectTo: siteUrl, data: { username: username.trim().toLowerCase(), display_name: displayName.trim() || username.trim() } } });
        if (error) throw error;
        if (data.session) { notify('Conta criada! Bem-vindo ao Plosbi.', 'success'); }
        else notify('Cadastro enviado. Confira seu e-mail (e o spam) para confirmar a conta.', 'success');
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email: email.trim().toLowerCase(), password });
        if (error) throw error; notify('Login realizado.', 'success');
      }
    } catch (error) { notify(friendlyError(error), 'error'); } finally { setBusy(false); }
  }
  return <main className="auth-screen"><div className="auth-glow glow-one"/><div className="auth-glow glow-two"/>
    <section className="auth-layout"><div className="auth-brand"><div className="brand-lockup"><ButterflyMark size={62}/><span>Plosbi</span></div><p className="auth-tagline">Conecte-se. Compartilhe. Viva.</p></div>
      <form className="auth-card" onSubmit={submit}><div className="auth-card-heading"><span className="auth-mini-mark"><ButterflyMark size={27}/></span><div><h2>{mode === 'login' ? 'Que bom ter você de volta' : 'Crie suas asas'}</h2><p>{mode === 'login' ? 'Entre para continuar sua jornada.' : 'Seu espaço social começa aqui.'}</p></div></div>
        <div className="auth-tabs"><button type="button" className={mode === 'login' ? 'selected' : ''} onClick={() => setMode('login')}>Entrar</button><button type="button" className={mode === 'signup' ? 'selected' : ''} onClick={() => setMode('signup')}>Criar conta</button></div>
        <button type="button" className="button auth-github" onClick={signInWithGitHub} disabled={busy}>
          <svg width="19" height="19" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 .9a11.1 11.1 0 0 0-3.51 21.63c.56.1.76-.24.76-.54v-2.1c-3.1.68-3.76-1.32-3.76-1.32-.51-1.3-1.25-1.65-1.25-1.65-1.02-.7.08-.69.08-.69 1.13.08 1.72 1.16 1.72 1.16 1 .1.75 2.23 3.53 1.58.1-.73.39-1.23.7-1.51-2.48-.28-5.09-1.24-5.09-5.52 0-1.22.44-2.21 1.16-2.99-.12-.28-.5-1.42.11-2.95 0 0 .95-.3 3.05 1.14a10.6 10.6 0 0 1 5.55 0c2.1-1.44 3.04-1.14 3.04-1.14.61 1.53.23 2.67.12 2.95.72.78 1.15 1.77 1.15 2.99 0 4.29-2.62 5.23-5.11 5.51.4.35.75 1.03.75 2.08v3.06c0 .3.2.65.77.54A11.1 11.1 0 0 0 12 .9Z"/></svg>
          Continuar com GitHub
        </button>
        <div className="auth-divider"><span>ou entre com e-mail</span></div>
        {mode === 'signup' && <><label className="input-label">Nome de exibição<input value={displayName} onChange={e => setDisplayName(e.target.value)} maxLength={50} placeholder="Como as pessoas te conhecem" autoComplete="name"/></label><label className="input-label">Nome de usuário<input value={username} onChange={e => setUsername(e.target.value.toLowerCase().replace(/^@/,''))} maxLength={24} placeholder="seu.usuario" autoComplete="username" required/></label></>}
        <label className="input-label">E-mail<input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="voce@exemplo.com" autoComplete="email" required/></label>
        <label className="input-label">Senha<div className="password-field"><input type={showPassword ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} placeholder="Mínimo de 8 caracteres" minLength={8} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} required/><button type="button" onClick={() => setShowPassword(v => !v)}>{showPassword ? 'Ocultar' : 'Mostrar'}</button></div></label>
        <button className="button button-primary auth-submit" disabled={busy}>{busy ? <><LoaderCircle className="spin" size={17}/> Aguarde...</> : mode === 'login' ? 'Entrar na minha conta' : 'Criar minha conta'} <span>→</span></button>
        {!hasSupabaseConfig && <div className="config-warning">A conexão ainda não foi configurada. Copie <code>.env.example</code> para <code>.env</code> e adicione as chaves do Supabase.</div>}
        <p className="auth-terms">Ao continuar, você concorda em usar a comunidade com respeito e segurança.</p>
      </form></section>
  </main>;
}

export default function App() {
  const [sessionUser, setSessionUser] = useState<any>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [page, setPage] = useState<Page>('feed');
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [comments, setComments] = useState<Comment[]>([]);
  const [likes, setLikes] = useState<Record<string, string[]>>({});
  const [savedPosts, setSavedPosts] = useState<string[]>(() => { try { return JSON.parse(localStorage.getItem('butterfly-saved-posts') || '[]'); } catch { return []; } });
  const [following, setFollowing] = useState<string[]>([]);
  const [myProfile, setMyProfile] = useState<Profile | null>(null);
  const [activeProfile, setActiveProfile] = useState<Profile | null>(null);
  const [query, setQuery] = useState(''); const [composerText, setComposerText] = useState('');
  const [composerFile, setComposerFile] = useState<File | null>(null); const [composerPreview, setComposerPreview] = useState('');
  const [busy, setBusy] = useState(false); const [toasts, setToasts] = useState<Toast[]>([]);
  const [theme, setTheme] = useState<Theme>(() => (localStorage.getItem('butterfly-theme') as Theme) || 'light');
  const [accent, setAccent] = useState(() => localStorage.getItem('butterfly-accent') || '#0a7cff');
  const [font, setFont] = useState(() => localStorage.getItem('butterfly-font') || 'Inter');
  const [readReceipts, setReadReceipts] = useState(() => localStorage.getItem('butterfly-read-receipts') !== 'false');
  const [dailyLimit, setDailyLimit] = useState(() => Number(localStorage.getItem('butterfly-daily-limit') || 60));
  const [breakMinutes, setBreakMinutes] = useState(() => Number(localStorage.getItem('butterfly-break-minutes') || 30));
  const [quietEnabled, setQuietEnabled] = useState(() => localStorage.getItem('butterfly-quiet') === 'true');
  const [quietStart, setQuietStart] = useState(() => localStorage.getItem('butterfly-quiet-start') || '22:00');
  const [quietEnd, setQuietEnd] = useState(() => localStorage.getItem('butterfly-quiet-end') || '07:00');
  const [minutesUsed, setMinutesUsed] = useState(() => Number(localStorage.getItem('butterfly-minutes-used') || 0));
  const [activeConversation, setActiveConversation] = useState<string | null>(null);
  const [conversationIds, setConversationIds] = useState<string[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [messageText, setMessageText] = useState(''); const [messageTarget, setMessageTarget] = useState<Profile | null>(null);
  const [serverName, setServerName] = useState(''); const [serverDescription, setServerDescription] = useState(''); const [inviteCode, setInviteCode] = useState('');
  const [servers, setServers] = useState<any[]>([]); const [serverMembers, setServerMembers] = useState<string[]>([]);
  const [uploadingAvatar, setUploadingAvatar] = useState(false); const [editingProfile, setEditingProfile] = useState(false); const [editName, setEditName] = useState(''); const [editUsername, setEditUsername] = useState(''); const [editBio, setEditBio] = useState(''); const [editAvatar, setEditAvatar] = useState('');
  const [mobileMenu, setMobileMenu] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null); const chatEndRef = useRef<HTMLDivElement>(null); 

  const notify = useCallback((text: string, kind: 'error' | 'success' = 'success') => {
    const now = new Date(); const current = now.getHours() * 60 + now.getMinutes(); const start = Number(quietStart.slice(0,2)) * 60 + Number(quietStart.slice(3,5)); const end = Number(quietEnd.slice(0,2)) * 60 + Number(quietEnd.slice(3,5)); const inHours = start === end ? true : start < end ? current >= start && current < end : current >= start || current < end;
    if (quietEnabled && inHours && kind !== 'error') return;
    const id = Date.now() + Math.random(); setToasts(old => [...old, { id, text, kind }]); window.setTimeout(() => setToasts(old => old.filter(t => t.id !== id)), 4200);
  }, [quietEnabled, quietStart, quietEnd]);
  useEffect(() => {
    if (!supabase || !Capacitor.isNativePlatform()) return;
    const sb = supabase;
    const handle = CapApp.addListener('appUrlOpen', async ({ url }) => {
      if (!url.startsWith('com.plosbi.social://auth-callback')) return;
      try {
        const query = new URLSearchParams(url.split('#')[0].split('?')[1] || '');
        const hash = new URLSearchParams(url.split('#')[1] || '');
        const code = query.get('code');
        const access_token = hash.get('access_token'); const refresh_token = hash.get('refresh_token');
        if (code) { const { error } = await sb.auth.exchangeCodeForSession(code); if (error) throw error; }
        else if (access_token && refresh_token) { const { error } = await sb.auth.setSession({ access_token, refresh_token }); if (error) throw error; }
        else { const msg = hash.get('error_description') || query.get('error_description'); if (msg) notify(msg, 'error'); }
      } catch (e) { notify(friendlyError(e), 'error'); }
      finally { void Browser.close().catch(() => undefined); }
    });
    return () => { void handle.then(h => h.remove()); };
  }, [notify]);
  const [convPartners, setConvPartners] = useState<string[]>([]);
  const [convMeta, setConvMeta] = useState<Record<string, { text: string; mine: boolean; unread: number; at: number }>>({});
  const loadPartners = useCallback(async () => {
    const client = supabase; if (!client || !sessionUser) return;
    let noReadCol = false;
    let mine: any = await client.from('conversation_members').select('conversation_id,last_read_at').eq('user_id', sessionUser.id);
    if (mine.error) { noReadCol = true; mine = await client.from('conversation_members').select('conversation_id').eq('user_id', sessionUser.id); }
    const mem = (mine.data ?? []) as { conversation_id: string; last_read_at?: string | null }[];
    const ids = mem.map(r => r.conversation_id);
    if (!ids.length) { setConvPartners([]); setConvMeta({}); return; }
    const [others, recent] = await Promise.all([
      client.from('conversation_members').select('conversation_id,user_id').in('conversation_id', ids).neq('user_id', sessionUser.id),
      client.from('messages').select('conversation_id,sender_id,content,created_at').in('conversation_id', ids).order('created_at', { ascending: false }).limit(300)
    ]);
    const partnerOf = new Map(((others.data ?? []) as { conversation_id: string; user_id: string }[]).map(r => [r.conversation_id, r.user_id]));
    const readAt = new Map(mem.map(r => [r.conversation_id, r.last_read_at ? Date.parse(r.last_read_at) : 0]));
    const meta: Record<string, { text: string; mine: boolean; unread: number; at: number }> = {};
    for (const m of (recent.data ?? []) as { conversation_id: string; sender_id: string; content: string; created_at: string }[]) {
      const pid = partnerOf.get(m.conversation_id); if (!pid) continue;
      const t = Date.parse(m.created_at);
      const e = meta[pid] ?? (meta[pid] = { text: String(m.content || '').replace(/\s+/g, ' ').trim(), mine: m.sender_id === sessionUser.id, unread: 0, at: t });
      if (!noReadCol && m.sender_id !== sessionUser.id && t > (readAt.get(m.conversation_id) ?? 0)) e.unread += 1;
    }
    setConvPartners(Array.from(new Set(partnerOf.values())).sort((x, y) => (meta[y]?.at ?? 0) - (meta[x]?.at ?? 0)));
    setConvMeta(meta);
  }, [sessionUser]);
  useEffect(() => { void loadPartners(); }, [loadPartners, page, activeConversation]);
  useEffect(() => {
    const client = supabase; if (!client || !sessionUser) return;
    const ch = client.channel('ps-inbox').on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, () => { void loadPartners(); }).subscribe();
    return () => { void client.removeChannel(ch); };
  }, [sessionUser, loadPartners]);
  useEffect(() => {
    const client = supabase; if (!client || !sessionUser || !activeConversation || page !== 'messages') return;
    void client.rpc('ps_mark_read', { p_conversation: activeConversation }).then(() => loadPartners());
  }, [activeConversation, page, messages.length, sessionUser, loadPartners]);

  useEffect(() => {
    document.documentElement.dataset.theme = theme; document.documentElement.style.setProperty('--accent', accent); document.documentElement.style.setProperty('--font-family', font);
    localStorage.setItem('butterfly-theme', theme); localStorage.setItem('butterfly-accent', accent); localStorage.setItem('butterfly-font', font);
  }, [theme, accent, font]);
  useEffect(() => { localStorage.setItem('butterfly-read-receipts', String(readReceipts)); }, [readReceipts]);
  useEffect(() => { localStorage.setItem('butterfly-saved-posts', JSON.stringify(savedPosts)); }, [savedPosts]);
  useEffect(() => { localStorage.setItem('butterfly-daily-limit', String(dailyLimit)); }, [dailyLimit]);
  useEffect(() => { localStorage.setItem('butterfly-break-minutes', String(breakMinutes)); }, [breakMinutes]);
  useEffect(() => { localStorage.setItem('butterfly-quiet', String(quietEnabled)); }, [quietEnabled]);
  useEffect(() => { localStorage.setItem('butterfly-quiet-start', quietStart); localStorage.setItem('butterfly-quiet-end', quietEnd); }, [quietStart, quietEnd]);
  useEffect(() => { const key = 'butterfly-day'; const today = new Date().toDateString(); if (localStorage.getItem(key) !== today) { localStorage.setItem(key, today); localStorage.setItem('butterfly-minutes-used', '0'); setMinutesUsed(0); } const t = window.setInterval(() => { if (document.visibilityState !== 'visible') return; setMinutesUsed(n => { const next = n + 1; localStorage.setItem('butterfly-minutes-used', String(next)); return next; }); }, 60000); return () => window.clearInterval(t); }, []);
  useEffect(() => { if (minutesUsed > 0 && breakMinutes > 0 && minutesUsed % breakMinutes === 0) notify('Hora de uma pausa rápida: levante, alongue-se e descanse os olhos.'); }, [minutesUsed, breakMinutes, notify]);

  useEffect(() => {
    if (!supabase) { setAuthLoading(false); return; }
    let alive = true;
    supabase.auth.getSession().then(({ data }) => { if (alive) { setSessionUser(data.session?.user ?? null); setAuthLoading(false); } });
    const { data } = supabase.auth.onAuthStateChange((_event, session) => { setSessionUser(session?.user ?? null); setAuthLoading(false); });
    return () => { alive = false; data.subscription.unsubscribe(); };
  }, []);

  const loadData = useCallback(async () => {
    if (!supabase || !sessionUser) return;
    setBusy(true);
    try {
      const [profileRes, postRes, followRes, serverRes] = await Promise.all([
        supabase.from('profiles').select('id,username,display_name,bio,avatar_url,created_at').order('created_at', { ascending: true }),
        supabase.from('posts').select('id,author_id,content,media_url,created_at').order('created_at', { ascending: false }).limit(80),
        supabase.from('follows').select('following_id').eq('follower_id', sessionUser.id),
        supabase.from('servers').select('id,name,description,owner_id,created_at').order('created_at', { ascending: false }).limit(50)
      ]);
      if (profileRes.error) throw profileRes.error; if (postRes.error) throw postRes.error;
      const ps = profileRes.data as Profile[]; const po = postRes.data as Post[];
      setProfiles(ps); setPosts(po); setFollowing((followRes.data ?? []).map((x: any) => x.following_id)); setServers(serverRes.data ?? []);
      setMyProfile(ps.find(p => p.id === sessionUser.id) ?? null);
      const postIds = po.map(p => p.id);
      if (postIds.length) {
        const [likeRes, commentRes] = await Promise.all([
          supabase.from('post_likes').select('post_id,user_id').in('post_id', postIds),
          supabase.from('comments').select('id,post_id,author_id,content,created_at').in('post_id', postIds).order('created_at', { ascending: true })
        ]);
        if (!likeRes.error) { const map: Record<string, string[]> = {}; (likeRes.data ?? []).forEach((x: any) => { (map[x.post_id] ||= []).push(x.user_id); }); setLikes(map); }
        if (!commentRes.error) setComments(commentRes.data as Comment[]);
      } else { setLikes({}); setComments([]); }
      const memberRes = await supabase.from('server_members').select('server_id').eq('user_id', sessionUser.id);
      setServerMembers((memberRes.data ?? []).map((x: any) => x.server_id));
    } catch (error) { notify(friendlyError(error), 'error'); } finally { setBusy(false); }
  }, [sessionUser, notify]);

  useEffect(() => { if (sessionUser) loadData(); else { setProfiles([]); setPosts([]); setComments([]); setMyProfile(null); } }, [sessionUser, loadData]);
  useEffect(() => { const client = supabase; if (!client || !sessionUser) return; const channel = client.channel('butterfly-feed-live').on('postgres_changes', { event: '*', schema: 'public', table: 'posts' }, () => loadData()).on('postgres_changes', { event: '*', schema: 'public', table: 'post_likes' }, () => loadData()).on('postgres_changes', { event: '*', schema: 'public', table: 'comments' }, () => loadData()).subscribe(); return () => { void client.removeChannel(channel); }; }, [sessionUser, loadData]);

  const profilesById = useMemo(() => Object.fromEntries(profiles.map(p => [p.id, p])), [profiles]);
  const visiblePosts = useMemo(() => {
    const filtered = page === 'profile' ? posts.filter(p => p.author_id === (activeProfile?.id ?? myProfile?.id)) : posts;
    const q = query.trim().toLowerCase(); if (!q) return filtered;
    return filtered.filter(p => (p.content || '').toLowerCase().includes(q) || (profilesById[p.author_id]?.username || '').toLowerCase().includes(q) || (profilesById[p.author_id]?.display_name || '').toLowerCase().includes(q));
  }, [page, posts, activeProfile, myProfile, query, profilesById]);

  async function refresh() { await loadData(); }
  async function logout() { if (!supabase) return; const { error } = await supabase.auth.signOut(); if (error) notify(friendlyError(error), 'error'); else { setPage('feed'); notify('Você saiu da conta.'); } }
  async function publishPost(e: FormEvent) {
    e.preventDefault(); if (!supabase || !sessionUser) return; if (!composerText.trim() && !composerFile) return notify('Escreva algo ou escolha uma imagem.', 'error'); setBusy(true);
    try {
      let mediaUrl: string | null = null;
      if (composerFile) {
        if (!['image/jpeg','image/png','image/webp'].includes(composerFile.type)) throw new Error('Use uma imagem JPG, PNG ou WebP.');
        if (composerFile.size > 25 * 1024 * 1024) throw new Error('A imagem deve ter no máximo 25 MB.');
        const path = `${sessionUser.id}/${crypto.randomUUID()}.jpg`;
        const { error: uploadError } = await supabase.storage.from('posts').upload(path, await resizeImage(composerFile, 1600, false), { upsert: false, contentType: 'image/jpeg' }); if (uploadError) throw uploadError;
        mediaUrl = supabase.storage.from('posts').getPublicUrl(path).data.publicUrl;
      }
      const { error } = await supabase.from('posts').insert({ author_id: sessionUser.id, content: composerText.trim() || null, media_url: mediaUrl }); if (error) throw error;
      setComposerText(''); setComposerFile(null); setComposerPreview(''); if (fileRef.current) fileRef.current.value = ''; notify('Publicação enviada!'); await loadData();
    } catch (error) { notify(friendlyError(error), 'error'); } finally { setBusy(false); }
  }
  async function toggleLike(post: Post) {
    if (!supabase || !sessionUser) return; const liked = (likes[post.id] || []).includes(sessionUser.id);
    setLikes(old => ({ ...old, [post.id]: liked ? (old[post.id] || []).filter(id => id !== sessionUser.id) : [...(old[post.id] || []), sessionUser.id] }));
    const result = liked ? await supabase.from('post_likes').delete().eq('post_id', post.id).eq('user_id', sessionUser.id) : await supabase.from('post_likes').insert({ post_id: post.id, user_id: sessionUser.id });
    if (result.error) { notify(friendlyError(result.error), 'error'); await loadData(); }
  }
  async function deletePost(post: Post) {
    if (!supabase || !sessionUser || post.author_id !== sessionUser.id) return;
    if (!window.confirm('Excluir esta publicação? Esta ação não pode ser desfeita.')) return;
    const { error } = await supabase.from('posts').delete().eq('id', post.id).eq('author_id', sessionUser.id);
    if (error) notify(friendlyError(error), 'error'); else { setSavedPosts(old => old.filter(id => id !== post.id)); notify('Publicação excluída.'); await loadData(); }
  }
  function toggleSavedPost(postId: string) { setSavedPosts(old => old.includes(postId) ? old.filter(id => id !== postId) : [...old, postId]); notify(savedPosts.includes(postId) ? 'Publicação removida dos salvos.' : 'Publicação salva neste dispositivo.'); }
  async function addComment(postId: string, text: string) {
    if (!supabase || !sessionUser || !text.trim()) return; const { error } = await supabase.from('comments').insert({ post_id: postId, author_id: sessionUser.id, content: text.trim() }); if (error) notify(friendlyError(error), 'error'); else { await loadData(); }
  }
  async function toggleFollow(targetId: string) {
    if (!supabase || !sessionUser || targetId === sessionUser.id) return; const exists = following.includes(targetId); setFollowing(old => exists ? old.filter(id => id !== targetId) : [...old, targetId]);
    const result = exists ? await supabase.from('follows').delete().eq('follower_id', sessionUser.id).eq('following_id', targetId) : await supabase.from('follows').insert({ follower_id: sessionUser.id, following_id: targetId });
    if (result.error) { notify(friendlyError(result.error), 'error'); await loadData(); }
  }
  async function saveProfile(e: FormEvent) {
    e.preventDefault(); if (!supabase || !sessionUser) return;
    const username = editUsername.trim().toLowerCase().replace(/^@/, ''); if (!/^[a-z0-9._]{3,24}$/.test(username)) return notify('O @ deve ter 3–24 caracteres: letras minúsculas, números, ponto ou sublinhado.', 'error');
    setBusy(true); try {
      const { error } = await supabase.from('profiles').update({ username, display_name: editName.trim().slice(0,50), bio: editBio.trim().slice(0,180), avatar_url: editAvatar.trim() || null }).eq('id', sessionUser.id); if (error) throw error;
      setEditingProfile(false); notify('Perfil atualizado.'); await loadData();
    } catch (error) { notify(friendlyError(error), 'error'); } finally { setBusy(false); }
  }
  async function uploadAvatar(file?: File) {
    if (!file || !supabase || !sessionUser) return;
    if (!['image/jpeg','image/png','image/webp'].includes(file.type)) return notify('Escolha uma imagem JPG, PNG ou WebP.', 'error');
    if (file.size > 25 * 1024 * 1024) return notify('A imagem é muito grande (máximo 25 MB).', 'error');
    if (!navigator.onLine) return notify('Sem conexão com a internet.', 'error');
    setUploadingAvatar(true);
    try {
      const blob = await resizeImage(file, 512, true);
      const path = `${sessionUser.id}/avatar-${Date.now()}.jpg`;
      const { error } = await supabase.storage.from('avatars').upload(path, blob, { upsert: false, contentType: 'image/jpeg' });
      if (error) throw error;
      const url = supabase.storage.from('avatars').getPublicUrl(path).data.publicUrl;
      const { error: saveError } = await supabase.from('profiles').update({ avatar_url: url }).eq('id', sessionUser.id);
      if (saveError) throw saveError;
      setEditAvatar(url); notify('Foto de perfil atualizada.', 'success'); await loadData();
    } catch (error) { notify(friendlyError(error), 'error'); } finally { setUploadingAvatar(false); }
  }
  async function openDM(target: Profile) {
    if (!supabase || !sessionUser) return; if (target.id === sessionUser.id) return notify('Escolha outra pessoa para iniciar uma conversa.', 'error');
    setMessageTarget(target); setPage('messages');
    try {
      const { data, error } = await supabase.rpc('ps_get_or_create_dm', { p_other: target.id }); if (error) throw error;
      const id = data as string; setActiveConversation(id); setConversationIds(old => old.includes(id) ? old : [...old, id]); await loadMessages(id);
    } catch (error) { notify(`${friendlyError(error)} Se a função ps_get_or_create_dm ainda não existe, aplique a etapa SQL corrigida do projeto.`, 'error'); }
  }
  async function loadMessages(conversationId: string) {
    if (!supabase) return; const { data, error } = await supabase.from('messages').select('id,conversation_id,sender_id,content,created_at').eq('conversation_id', conversationId).order('created_at', { ascending: true }).limit(300); if (error) notify(friendlyError(error), 'error'); else setMessages(data as Message[]);
  }
  async function sendMessage(e: FormEvent) {
    e.preventDefault(); if (!supabase || !sessionUser || !activeConversation || !messageText.trim()) return;
    if (!navigator.onLine) { notify('Sem conexão com a internet. Sua mensagem não foi enviada.', 'error'); return; }
    const text = messageText.trim(); setMessageText(''); const { error } = await supabase.from('messages').insert({ conversation_id: activeConversation, sender_id: sessionUser.id, content: text }); if (error) { setMessageText(text); notify(friendlyError(error), 'error'); } else await loadMessages(activeConversation);
  }
  useEffect(() => { const client = supabase; if (!client || !activeConversation) return; loadMessages(activeConversation); const channel = client.channel(`butterfly-chat-${activeConversation}`).on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `conversation_id=eq.${activeConversation}` }, payload => setMessages(old => old.some(m => m.id === (payload.new as Message).id) ? old : [...old, payload.new as Message])).subscribe(); return () => { void client.removeChannel(channel); }; }, [activeConversation]);
  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' }); }, [messages]);
  async function createServer(e: FormEvent) {
    e.preventDefault(); if (!supabase || !sessionUser || serverName.trim().length < 2) return notify('O nome do servidor precisa ter pelo menos 2 caracteres.', 'error'); setBusy(true);
    try { const { data, error } = await supabase.from('servers').insert({ name: serverName.trim().slice(0,50), description: serverDescription.trim().slice(0,500), owner_id: sessionUser.id }).select('id,name,description,owner_id,created_at').single(); if (error) throw error;
      const { error: memberError } = await supabase.from('server_members').upsert({ server_id: data.id, user_id: sessionUser.id, role: 'owner' }, { onConflict: 'server_id,user_id', ignoreDuplicates: true }); if (memberError) throw memberError;
      setServerName(''); setServerDescription(''); notify('Servidor criado! Você é o owner.'); await loadData();
    } catch (error) { notify(friendlyError(error), 'error'); } finally { setBusy(false); }
  }
  async function joinServer(e: FormEvent) { e.preventDefault(); if (!supabase || !inviteCode.trim()) return; try { const { data, error } = await supabase.rpc('ps_join_server', { p_code: inviteCode.trim() }); if (error) throw error; setInviteCode(''); notify('Você entrou no servidor!'); await loadData(); } catch (error) { notify(`${friendlyError(error)} Confirme se a função ps_join_server já foi criada no Supabase.`, 'error'); } }
  async function createInvite(serverId: string) { if (!supabase || !sessionUser) return; const code = crypto.randomUUID().replace(/-/g, '').slice(0,12).toUpperCase(); const { error } = await supabase.from('server_invites').insert({ server_id: serverId, code, created_by: sessionUser.id, max_uses: 25, uses: 0 }); if (error) notify(friendlyError(error), 'error'); else { try { await navigator.clipboard.writeText(code); notify(`Convite ${code} copiado!`, 'success'); } catch { notify(`Código do convite: ${code}`, 'success'); } } }

  function navigate(next: Page) { setPage(next); setMobileMenu(false); if (next === 'profile') setActiveProfile(myProfile); if (next === 'messages') { setMessageTarget(null); setActiveConversation(null); setMessages([]); } }
  function beginEditProfile() { setEditName(myProfile?.display_name || ''); setEditUsername(myProfile?.username || ''); setEditBio(myProfile?.bio || ''); setEditAvatar(myProfile?.avatar_url || ''); setEditingProfile(true); }
  function selectProfile(p: Profile) { setActiveProfile(p); setPage('profile'); setMobileMenu(false); }

  if (authLoading) return <div className="loading-screen"><ButterflyMark size={48}/><LoaderCircle className="spin"/> Preparando seu espaço...</div>;
  if (!sessionUser) return <><AuthScreen notify={notify}/><ToastStack toasts={toasts}/></>;

  const navItems: { id: Page; label: string; icon: any }[] = [
    { id: 'feed', label: 'Início', icon: Home }, { id: 'explore', label: 'Explorar', icon: Compass }, { id: 'messages', label: 'Mensagens', icon: MessageCircle }, { id: 'servers', label: 'Servidores', icon: Users }, { id: 'profile', label: 'Perfil', icon: UserRound }
  ];
  const openEdit = editingProfile;
  return <div className={`app app-${theme}`}>
    <header className="topbar"><button className="brand-button" onClick={() => navigate('feed')}><ButterflyMark/><span>Plosbi</span></button>
            <div className="topbar-actions"><button className="icon-button" title="Bem-estar digital" onClick={() => navigate('wellbeing')}><Clock3 size={19}/></button><button className="icon-button" title="Configurações" onClick={() => navigate('settings')}><Settings size={19}/></button><Avatar profile={myProfile} size="sm" onClick={() => navigate('profile')}/><button className="icon-button logout-button" title="Sair" onClick={logout}><LogOut size={18}/></button></div>
    </header>
    <div className="workspace"><aside className={`sidebar ${mobileMenu ? 'sidebar-open' : ''}`}><div className="sidebar-profile"><Avatar profile={myProfile} size="lg" onClick={() => navigate('profile')}/><div className="sidebar-user"><strong>{myProfile?.display_name || myProfile?.username || 'Sua conta'}</strong><span>@{myProfile?.username || 'usuario'}</span></div><button className="tiny-icon" onClick={() => navigate('settings')}><ChevronDown size={15}/></button></div><div className="sidebar-label">SEU ESPAÇO</div>
      {navItems.map(item => { const Icon = item.icon; return <button key={item.id} className={`nav-item ${page === item.id ? 'nav-active' : ''}`} onClick={() => navigate(item.id)}><Icon size={19}/><span>{item.label}</span>{item.id === 'messages' && <i className="nav-dot"/>}</button>; })}
      <div className="sidebar-label sidebar-label-spaced">PERSONALIZE</div><button className={`nav-item ${page === 'settings' ? 'nav-active' : ''}`} onClick={() => navigate('settings')}><Palette size={19}/><span>Aparência</span></button><button className={`nav-item ${page === 'wellbeing' ? 'nav-active' : ''}`} onClick={() => navigate('wellbeing')}><Activity size={19}/><span>Bem-estar digital</span></button>
      <div className="sidebar-bottom"><div className="sidebar-butterfly"><ButterflyMark size={28}/><div><strong>Plosbi Plus</strong><span>Seu universo, suas regras.</span></div></div><button className="nav-item" onClick={logout}><LogOut size={19}/><span>Sair da conta</span></button></div>
    </aside>
    <main className="main-column">
      {page === 'feed' && <><StoriesBar meId={sessionUser.id} notify={notify}/>
        <form className="composer panel" id="post-composer" onSubmit={publishPost}><Avatar profile={myProfile} size="md"/><div className="composer-content"><textarea value={composerText} onChange={e => setComposerText(e.target.value)} placeholder={`O que está passando pela sua cabeça, ${myProfile?.display_name || myProfile?.username || 'criador'}?`} rows={2} maxLength={2000}/>{composerPreview && <div className="composer-preview"><img src={composerPreview} alt="Prévia da publicação"/><button type="button" onClick={() => {setComposerFile(null);setComposerPreview('');if(fileRef.current)fileRef.current.value='';}} aria-label="Remover imagem"><X size={15}/></button></div>}<div className="composer-footer"><button type="button" className="composer-tool" onClick={() => fileRef.current?.click()}><ImagePlus size={17}/> Foto</button><input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp" hidden onChange={e => { const f=e.target.files?.[0]; if(!f)return; if(f.size>5*1024*1024){notify('A imagem deve ter até 5 MB.','error');e.target.value='';return;} setComposerFile(f);setComposerPreview(URL.createObjectURL(f)); }}/><span className="composer-count">{composerText.length}/2000</span><button className="button button-primary" disabled={busy || (!composerText.trim() && !composerFile)}>{busy ? <LoaderCircle className="spin" size={16}/> : <Send size={15}/>} Publicar</button></div></div></form>
        <Feed posts={visiblePosts} profiles={profilesById} likes={likes} comments={comments} userId={sessionUser.id} savedPosts={savedPosts} onSave={toggleSavedPost} onDelete={deletePost} onLike={toggleLike} onComment={addComment} onProfile={selectProfile} onMessage={openDM} onRefresh={refresh} notify={notify}/>
      </>}
      {page === 'explore' && <><div className="page-heading"><div><span className="eyebrow">DESCUBRA ALGO NOVO</span><h1>Explorar<span className="heading-period">.</span></h1><p>Encontre pessoas e publicações que combinam com você.</p></div></div><div className="explore-search panel"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Busque por texto, nome ou @usuário" autoFocus/></div><div className="people-grid">{profiles.filter(p=>p.id!==sessionUser.id && (`${p.username} ${p.display_name||''} ${p.bio||''}`).toLowerCase().includes(query.toLowerCase())).map(p=><PersonCard key={p.id} profile={p} following={following.includes(p.id)} onFollow={()=>toggleFollow(p.id)} onProfile={()=>selectProfile(p)} onMessage={()=>openDM(p)}/>)}</div><Feed posts={visiblePosts} profiles={profilesById} likes={likes} comments={comments} userId={sessionUser.id} savedPosts={savedPosts} onSave={toggleSavedPost} onDelete={deletePost} onLike={toggleLike} onComment={addComment} onProfile={selectProfile} onMessage={openDM} onRefresh={refresh} notify={notify}/></>}
      {page === 'profile' && <><div className="profile-hero panel"><div className="profile-cover"><div className="cover-orbit orbit-a"/><div className="cover-orbit orbit-b"/><ButterflyMark size={100}/></div><div className="profile-details"><Avatar profile={activeProfile || myProfile} size="xl"/><div className="profile-action-row">{(activeProfile?.id || myProfile?.id) === sessionUser.id ? <button className="button button-primary" onClick={beginEditProfile}><Settings size={16}/> Editar perfil</button> : <><button className="button button-primary" onClick={()=>activeProfile&&toggleFollow(activeProfile.id)}>{following.includes(activeProfile?.id||'')?'Seguindo':'Seguir'}</button><button className="button button-secondary" onClick={()=>activeProfile&&openDM(activeProfile)}><MessageCircle size={16}/> Mensagem</button></>}</div><h2>{(activeProfile || myProfile)?.display_name || (activeProfile || myProfile)?.username || 'Perfil'}</h2><div className="profile-handle">@{(activeProfile || myProfile)?.username}</div><p className="profile-bio">{(activeProfile || myProfile)?.bio || 'Ainda não adicionou uma bio. Conte um pouco sobre você.'}</p><div className="profile-stats"><span><b>{posts.filter(p=>p.author_id===(activeProfile?.id||myProfile?.id)).length}</b> publicações</span><span><b>{profiles.length ? following.length : 0}</b> seguindo</span><span><b>{profiles.filter(p=>following.includes(p.id)).length}</b> conexões</span></div></div></div><div className="section-heading"><h2>Publicações</h2><span>GRADE DO PERFIL</span></div><div className="profile-grid">{visiblePosts.map(p=><button key={p.id} className="profile-grid-item" onClick={()=>notify((p.content||'Publicação sem legenda').slice(0,150))}>{p.media_url?<img src={p.media_url} alt="Publicação"/>:<div className="grid-text">{p.content}</div>}<span><Heart size={15}/>{likes[p.id]?.length||0}</span></button>)}{!visiblePosts.length&&<div className="empty-state">Ainda não há publicações neste perfil.</div>}</div></>}
      {page === 'messages' && <MessagesPage profiles={profiles.filter(p=>p.id!==sessionUser.id)} partners={convPartners} meta={convMeta} currentUser={sessionUser.id} messages={messages} activeConversation={activeConversation} target={messageTarget} text={messageText} setText={setMessageText} onSend={sendMessage} onChoose={openDM} onLoad={loadMessages} endRef={chatEndRef} receipts={readReceipts} notify={notify}/>}
      {page === 'servers' && <><div className="page-heading"><div><span className="eyebrow">COMUNIDADES</span><h1>Servidores<span className="heading-period">.</span></h1><p>Crie um espaço para juntar sua comunidade.</p></div></div><form className="panel server-form" onSubmit={createServer}><h3><Plus size={18}/> Criar servidor</h3><label className="input-label">Nome do servidor<input value={serverName} onChange={e=>setServerName(e.target.value)} maxLength={50} minLength={2} required placeholder="Ex.: Comunidade Plosbi"/></label><label className="input-label">Descrição<input value={serverDescription} onChange={e=>setServerDescription(e.target.value)} maxLength={500} placeholder="Do que se trata esta comunidade?"/></label><button className="button button-primary" disabled={busy}><Plus size={16}/> Criar servidor</button></form><form className="panel join-server" onSubmit={joinServer}><div><h3>Entrar por convite</h3><p>Insira o código de convite do servidor.</p></div><input value={inviteCode} onChange={e=>setInviteCode(e.target.value)} placeholder="CÓDIGO DO CONVITE" required/><button className="button button-secondary">Entrar</button></form><div className="server-list">{servers.filter(s=>serverMembers.includes(s.id)||s.owner_id===sessionUser.id).map(s=><article className="panel server-card" key={s.id}><div className="server-emblem"><Users size={23}/></div><div className="server-info"><h3>{s.name}</h3><p>{s.description||'Uma comunidade Plosbi.'}</p><span>{s.owner_id===sessionUser.id?'Você é o proprietário':'Você participa'}</span></div>{s.owner_id===sessionUser.id&&<button className="button button-secondary" onClick={()=>createInvite(s.id)}><Plus size={15}/> Criar convite</button>}</article>)}{!servers.some(s=>serverMembers.includes(s.id)||s.owner_id===sessionUser.id)&&<div className="empty-state panel">Você ainda não participa de nenhum servidor.</div>}</div></>}
      {page === 'settings' && <><div className="page-heading"><div><span className="eyebrow">SEU ESPAÇO, SEU ESTILO</span><h1>Aparência<span className="heading-period">.</span></h1><p>Personalize a experiência do Plosbi.</p></div></div><section className="panel settings-panel"><div className="settings-title"><span className="settings-icon"><Palette/></span><div><h3>Tema do aplicativo</h3><p>Escolha o modo de visualização.</p></div></div><div className="theme-options"><button className={theme==='dark'?'chosen':''} onClick={()=>setTheme('dark')}><Moon size={19}/><span><b>Modo escuro</b><small>Azul noturno e preto</small></span>{theme==='dark'&&<Check size={17}/>}</button><button className={theme==='light'?'chosen':''} onClick={()=>setTheme('light')}><Sun size={19}/><span><b>Modo claro</b><small>Limpo e luminoso</small></span>{theme==='light'&&<Check size={17}/>}</button></div><div className="settings-divider"/><div className="settings-title"><span className="settings-icon"><Sparkles/></span><div><h3>Cor de destaque</h3><p>Botões, seleções e detalhes da interface.</p></div></div><div className="accent-options">{['#368bff','#27c3d8','#8b5cf6','#f472b6','#22c55e','#f59e0b'].map(c=><button key={c} className={accent===c?'accent-selected':''} style={{'--swatch':c} as CSSProperties} onClick={()=>setAccent(c)} aria-label={`Cor ${c}`}>{accent===c&&<Check size={17}/>}</button>)}<label className="custom-color">Personalizada<input type="color" value={accent} onChange={e=>setAccent(e.target.value)}/></label></div><div className="settings-divider"/><div className="settings-title"><span className="settings-icon"><span className="font-symbol">Aa</span></span><div><h3>Fonte</h3><p>Ajuste a tipografia do aplicativo.</p></div></div><select className="settings-select" value={font} onChange={e=>setFont(e.target.value)}><option>Inter</option><option>Arial</option><option>Georgia</option><option>system-ui</option></select><div className="settings-divider"/><div className="settings-title"><span className="settings-icon"><Bell/></span><div><h3>Confirmações de leitura</h3><p>Preferência local para recibos de leitura.</p></div><button className={`toggle ${readReceipts?'toggle-on':''}`} onClick={()=>setReadReceipts(v=>!v)} aria-label="Alternar confirmações de leitura"><span/></button></div><p className="settings-note">A preferência fica neste dispositivo; para recibos reais, é necessário adicionar uma coluna de leitura ao banco.</p></section><section className="panel settings-panel"><div className="settings-title"><span className="settings-icon"><ShieldCheck/></span><div><h3>Conta e segurança</h3><p>{sessionUser.email}</p></div></div><button className="button button-secondary" onClick={logout}><LogOut size={16}/> Sair da conta</button></section></>}
      {page === 'wellbeing' && <><div className="page-heading"><div><span className="eyebrow">EQUILÍBRIO DIGITAL</span><h1>Bem-estar<span className="heading-period">.</span></h1><p>Use o Plosbi no seu ritmo.</p></div></div><div className="wellbeing-grid"><section className="panel wellbeing-card"><span className="wellbeing-icon"><Clock3/></span><div className="eyebrow">TEMPO DE TELA HOJE</div><div className="time-number">{Math.floor(minutesUsed/60)}h {minutesUsed%60}m</div><div className="progress-track"><span style={{width:`${Math.min(100,minutesUsed/Math.max(1,dailyLimit)*100)}%`}}/></div><p>Limite diário: {dailyLimit} minutos</p><label className="input-label">Limite diário (minutos)<input type="number" min={5} max={1440} value={dailyLimit} onChange={e=>setDailyLimit(Math.min(1440,Math.max(5,Number(e.target.value)||5)))}/></label>{minutesUsed>=dailyLimit&&<div className="config-warning">Você alcançou seu limite diário definido.</div>}</section><section className="panel wellbeing-card"><span className="wellbeing-icon"><Activity/></span><h3>Lembretes de pausa</h3><p>Faça pequenas pausas para descansar a mente e os olhos.</p><label className="input-label">Lembrar a cada (minutos)<input type="number" min={5} max={240} value={breakMinutes} onChange={e=>setBreakMinutes(Math.min(240,Math.max(5,Number(e.target.value)||5)))}/></label><p className="settings-note">O intervalo é salvo neste dispositivo. As notificações de pausa não são enviadas enquanto o navegador estiver fechado.</p></section><section className="panel wellbeing-card"><span className="wellbeing-icon"><Moon/></span><h3>Modo silencioso</h3><p>Uma preferência para reduzir interrupções.</p><div className="settings-title quiet-row"><div><b>Não perturbe</b><small>Silencia avisos comuns durante o horário configurado.</small></div><button className={`toggle ${quietEnabled?'toggle-on':''}`} onClick={()=>setQuietEnabled(v=>!v)} aria-label="Ativar modo silencioso"><span/></button></div><div className="quiet-schedule"><label>Início<input type="time" value={quietStart} onChange={e=>setQuietStart(e.target.value)}/></label><label>Fim<input type="time" value={quietEnd} onChange={e=>setQuietEnd(e.target.value)}/></label></div><p className="settings-note">O horário usa a hora local deste dispositivo. Avisos de erro continuam visíveis.</p></section></div></>}
    </main>
    <aside className="right-rail"><section className="panel right-card profile-mini-card"><div className="rail-heading"><span>Seu perfil</span><button onClick={()=>navigate('profile')}>Ver perfil</button></div><div className="rail-profile"><Avatar profile={myProfile} size="lg" onClick={()=>navigate('profile')}/><div><strong>{myProfile?.display_name||myProfile?.username}</strong><span>@{myProfile?.username}</span></div></div><div className="rail-stats"><span><b>{posts.filter(p=>p.author_id===sessionUser.id).length}</b><small>Posts</small></span><span><b>{following.length}</b><small>Seguindo</small></span><span><b>{profiles.filter(p=>following.includes(p.id)).length}</b><small>Conexões</small></span></div></section><section className="panel right-card suggestions-card"><div className="rail-heading"><span>Talvez você conheça</span><button onClick={()=>navigate('explore')}>Ver todos</button></div>{profiles.filter(p=>p.id!==sessionUser.id&&!following.includes(p.id)).slice(0,4).map(p=><div className="suggestion" key={p.id}><Avatar profile={p} size="sm" onClick={()=>selectProfile(p)}/><button className="suggestion-name" onClick={()=>selectProfile(p)}><b>{p.display_name||p.username}</b><span>@{p.username}</span></button><button className="follow-plus" onClick={()=>toggleFollow(p.id)} aria-label={`Seguir ${p.username}`}><Plus size={16}/></button></div>)}{profiles.length<=1&&<p className="rail-muted">Novas pessoas aparecerão aqui conforme entrarem na comunidade.</p>}</section><section className="butterfly-promo"><ButterflyMark size={33}/><h3>Encontre suas asas.</h3><p>Uma comunidade feita para você ser você.</p></section><div className="rail-footer">Privacidade · Comunidade · Ajuda<br/>Plosbi Social © {new Date().getFullYear()}</div></aside>
    </div>
    <nav className="mobile-nav" aria-label="Navegação principal"><button className={page==='feed'?'mobile-active':''} onClick={()=>navigate('feed')} aria-label="Início"><Home size={24}/></button><button className={page==='explore'?'mobile-active':''} onClick={()=>navigate('explore')} aria-label="Buscar"><Search size={24}/></button><button className="mobile-plus" onClick={()=>{navigate('feed');setTimeout(()=>{const c=document.getElementById('post-composer');c?.scrollIntoView({behavior:'smooth',block:'center'});c?.querySelector('textarea')?.focus();},120);}} aria-label="Nova publicação"><Plus size={24}/></button><button className={page==='messages'?'mobile-active':''} onClick={()=>navigate('messages')} aria-label="Mensagens"><MessageCircle size={24}/>{Object.values(convMeta).some(x=>x.unread>0)&&<i className="nav-dot"/>}</button><button className={page==='profile'?'mobile-active':''} onClick={()=>navigate('profile')} aria-label="Perfil"><UserRound size={24}/></button></nav>
    {openEdit&&<div className="modal-backdrop" onClick={()=>setEditingProfile(false)}><form className="modal-card" onClick={e=>e.stopPropagation()} onSubmit={saveProfile}><button type="button" className="modal-close" onClick={()=>setEditingProfile(false)} aria-label="Fechar"><X size={18}/></button><div className="eyebrow">SEU ESPAÇO</div><h2>Editar perfil</h2><p>Personalize como as pessoas encontram você.</p><div className="avatar-edit-row"><Avatar profile={{...(myProfile||{} as Profile),avatar_url:editAvatar||myProfile?.avatar_url||null}} size="xl"/><label className="button button-secondary file-button"><Camera size={16}/> {uploadingAvatar?'Enviando...':'Enviar foto'}<input type="file" accept="image/jpeg,image/png,image/webp" disabled={uploadingAvatar} onChange={e=>{const f=e.target.files?.[0];e.target.value='';void uploadAvatar(f);}} hidden/></label></div><label className="input-label">Nome de exibição<input value={editName} onChange={e=>setEditName(e.target.value)} maxLength={50}/></label><label className="input-label">Nome de usuário<input value={editUsername} onChange={e=>setEditUsername(e.target.value)} maxLength={24}/></label><label className="input-label">Bio<textarea value={editBio} onChange={e=>setEditBio(e.target.value)} maxLength={180} rows={3}/><small>{editBio.length}/180</small></label><label className="input-label">URL da foto (opcional)<input value={editAvatar} onChange={e=>setEditAvatar(e.target.value)} type="url" placeholder="https://..."/></label><button className="button button-primary modal-submit" disabled={busy}>{busy?'Salvando...':'Salvar alterações'}</button></form></div>}
    {mobileMenu&&<button className="menu-scrim" onClick={()=>setMobileMenu(false)} aria-label="Fechar menu"/>}
    <ToastStack toasts={toasts}/>
  </div>;
}

function Feed({ posts, profiles, likes, comments, userId, savedPosts, onSave, onDelete, onLike, onComment, onProfile, onMessage, onRefresh, notify }: { posts: Post[]; profiles: Record<string,Profile>; likes: Record<string,string[]>; comments: Comment[]; userId: string; savedPosts:string[]; onSave:(id:string)=>void; onDelete:(post:Post)=>void; onLike:(post:Post)=>void; onComment:(postId:string,text:string)=>void; onProfile:(p:Profile)=>void; onMessage:(p:Profile)=>void; onRefresh:()=>void; notify:(text:string,kind?:'error'|'success')=>void }) {
  if (!posts.length) return <div className="empty-state panel"><div className="empty-art"><ButterflyMark size={58}/></div><h3>O feed está pronto para decolar.</h3><p>Seja a primeira pessoa a compartilhar algo ou convide alguém para a comunidade.</p><button className="button button-secondary" onClick={onRefresh}>Atualizar feed</button></div>;
  return <div className="feed-list">{posts.map(post=>{const author=profiles[post.author_id];const postComments=comments.filter(c=>c.post_id===post.id);return <article className="post-card panel" key={post.id}><div className="post-header"><Avatar profile={author} size="md" onClick={()=>author&&onProfile(author)}/><button className="post-author" onClick={()=>author&&onProfile(author)}><b>{author?.display_name||author?.username||'Usuário'}</b><span>@{author?.username||'usuario'} · {timeAgo(post.created_at)}</span></button>{author?.id!==userId&&author&&<button className="icon-button post-message" onClick={()=>onMessage(author)} title="Enviar mensagem"><MessageCircle size={17}/></button>}{author?.id===userId&&<button className="icon-button" onClick={()=>onDelete(post)} aria-label="Excluir publicação" title="Excluir publicação"><MoreHorizontal size={20}/></button>}</div>{post.content&&<p className="post-content">{post.content}</p>}{post.media_url&&<img className="post-media" src={post.media_url} alt="Imagem da publicação" loading="lazy"/>}<div className="post-reactions"><button className={(likes[post.id]||[]).includes(userId)?'reacted':''} onClick={()=>onLike(post)}><Heart size={19} fill={(likes[post.id]||[]).includes(userId)?'currentColor':'none'}/><span>{likes[post.id]?.length||0}</span></button><button onClick={()=>document.getElementById(`comment-${post.id}`)?.focus()}><MessageCircle size={19}/><span>{postComments.length}</span></button><button onClick={async()=>{try{await navigator.clipboard.writeText(`${author?.display_name||author?.username||'Plosbi'}: ${post.content||post.media_url||'Publicação'}`);notify('Texto da publicação copiado!');}catch{notify('Não foi possível copiar neste navegador.','error');}}}><Send size={18}/><span>Compartilhar</span></button><button className={`save-post ${savedPosts.includes(post.id)?'reacted':''}`} onClick={()=>onSave(post.id)} aria-label={savedPosts.includes(post.id)?'Remover dos salvos':'Salvar'} title={savedPosts.includes(post.id)?'Remover dos salvos':'Salvar'}><Bookmark size={18} fill={savedPosts.includes(post.id)?'currentColor':'none'}/></button></div>{postComments.length>0&&<div className="comment-list">{postComments.slice(-3).map(c=><p key={c.id}><b>{profiles[c.author_id]?.username||'usuario'}</b> {c.content}</p>)}</div>}<CommentForm postId={post.id} onSubmit={onComment}/></article>;})}</div>;
}
function CommentForm({postId,onSubmit}:{postId:string;onSubmit:(id:string,text:string)=>void}) { const [text,setText]=useState(''); return <form className="comment-box" onSubmit={e=>{e.preventDefault();if(!text.trim())return;onSubmit(postId,text);setText('');}}><input id={`comment-${postId}`} value={text} onChange={e=>setText(e.target.value)} maxLength={1000} placeholder="Adicione um comentário..."/><button disabled={!text.trim()} aria-label="Enviar comentário"><Send size={16}/></button></form>; }
function PersonCard({profile,following,onFollow,onProfile,onMessage}:{profile:Profile;following:boolean;onFollow:()=>void;onProfile:()=>void;onMessage:()=>void}) { return <article className="person-card panel"><div className="person-card-cover"><ButterflyMark size={42}/></div><Avatar profile={profile} size="xl" onClick={onProfile}/><h3>{profile.display_name||profile.username}</h3><span>@{profile.username}</span><p>{profile.bio||'Ainda não adicionou uma bio.'}</p><div><button className={`button ${following?'button-secondary':'button-primary'}`} onClick={onFollow}>{following?'Seguindo':'Seguir'}</button><button className="button button-secondary" onClick={onMessage}><MessageCircle size={15}/> Mensagem</button></div></article>; }
function MessagesPage({profiles,partners,meta,currentUser,messages,activeConversation,target,text,setText,onSend,onChoose,onLoad,endRef,receipts,notify}:{profiles:Profile[];partners:string[];meta:Record<string,{text:string;mine:boolean;unread:number}>;currentUser:string;messages:Message[];activeConversation:string|null;target:Profile|null;text:string;setText:(s:string)=>void;onSend:(e:FormEvent)=>void;onChoose:(p:Profile)=>void;onLoad:(id:string)=>void;endRef:RefObject<HTMLDivElement>;receipts:boolean;notify:(text:string,kind?:'error'|'success')=>void}) {
  const [search,setSearch]=useState(''); const [typingNames,setTypingNames]=useState<string[]>([]); const [chatBackground,setChatBackground]=useState('plain'); const typingChannel=useRef<any>(null); const typingTimer=useRef<number|undefined>(undefined);
  const filtered=(search.trim()?profiles:profiles.filter(p=>partners.includes(p.id)).sort((x,y)=>partners.indexOf(x.id)-partners.indexOf(y.id))).filter(p=>`${p.username} ${p.display_name||''}`.toLowerCase().includes(search.toLowerCase()));
  useEffect(()=>{ if(!activeConversation||!supabase)return; setChatBackground(localStorage.getItem(`butterfly-chat-bg-${activeConversation}`)||'plain'); const channel=supabase.channel(`butterfly-typing-${activeConversation}`,{config:{broadcast:{self:false}}}).on('broadcast',{event:'typing'},({payload})=>{const id=String(payload?.userId||'');if(!id||id===currentUser)return;setTypingNames(old=>payload?.typing?(old.includes(id)?old:[...old,id]):old.filter(x=>x!==id));}).subscribe();typingChannel.current=channel;return()=>{if(typingTimer.current)window.clearTimeout(typingTimer.current);supabase?.removeChannel(channel);typingChannel.current=null;setTypingNames([]);};},[activeConversation,currentUser]);
  function signalTyping(value:string){setText(value);if(!typingChannel.current||!activeConversation)return;typingChannel.current.send({type:'broadcast',event:'typing',payload:{userId:currentUser,typing:Boolean(value.trim())}});if(typingTimer.current)window.clearTimeout(typingTimer.current);if(value.trim())typingTimer.current=window.setTimeout(()=>typingChannel.current?.send({type:'broadcast',event:'typing',payload:{userId:currentUser,typing:false}}),1300);}
  function chooseBackground(bg:string){setChatBackground(bg);if(activeConversation)localStorage.setItem(`butterfly-chat-bg-${activeConversation}`,bg);}
  const [chatOpen,setChatOpen]=useState(false);const formRef=useRef<HTMLFormElement>(null);const taRef=useRef<HTMLTextAreaElement>(null);useEffect(()=>{if(!text&&taRef.current)taRef.current.style.height="auto"},[text]);function onComposerKey(e:ReactKeyboardEvent<HTMLTextAreaElement>){if(e.key==="Enter"&&!e.shiftKey&&!window.matchMedia("(pointer: coarse)").matches){e.preventDefault();if(text.trim())formRef.current?.requestSubmit()}}
  return <><div className="page-heading messages-heading"><div><span className="eyebrow">CONVERSAS PRIVADAS</span><h1>Mensagens<span className="heading-period">.</span></h1><p>Converse com a comunidade em tempo real.</p></div></div><div className={`messages-layout panel ${target&&activeConversation&&chatOpen?"chat-open":""}`}><aside className="chat-people"><div className="chat-people-title"><h3>Conversas</h3><button className="icon-button" onClick={()=>notify('Escolha uma pessoa na lista para iniciar uma conversa.')} aria-label="Nova conversa"><Plus size={17}/></button></div><label className="chat-search"><Search size={15}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Buscar pessoas"/></label>{filtered.map(p=><button key={p.id} className={`chat-person ${target?.id===p.id?'chat-person-active':''}`} onClick={()=>{onChoose(p);setChatOpen(true)}}><Avatar profile={p} size="md"/><span className="chat-person-text"><b>{p.display_name||p.username}</b><small className="chat-preview">{meta[p.id]?(meta[p.id].mine?'Você: ':'')+meta[p.id].text:'@'+p.username}</small></span>{(meta[p.id]?.unread??0)>0&&<i className="unread-dot" aria-label="Mensagens não lidas"/>}</button>)}{!filtered.length&&<p className="rail-muted">Nenhuma pessoa encontrada.</p>}</aside><section className="chat-window">{target&&activeConversation?<><header className="chat-header"><button type="button" className="icon-button chat-back" onClick={()=>setChatOpen(false)} aria-label="Voltar para as conversas"><ArrowLeft size={18}/></button><Avatar profile={target} size="md"/><div><b>{target.display_name||target.username}</b><small>@{target.username}</small></div><span className="chat-encrypted"><ShieldCheck size={14}/> Privado</span><label className="chat-bg-picker" title="Fundo da conversa"><Palette size={14}/><select aria-label="Fundo da conversa" value={chatBackground} onChange={e=>chooseBackground(e.target.value)}><option value="plain">Fundo</option><option value="blue">Azul</option><option value="aurora">Aurora</option></select></label><button className="icon-button" onClick={()=>onLoad(activeConversation)} title="Atualizar mensagens"><Activity size={17}/></button></header><div className={`chat-messages chat-bg-${chatBackground}`}>{messages.map(m=><div key={m.id} className={`message-row ${m.sender_id===currentUser?'message-mine':''}`}><div className="message-bubble">{m.content}<small>{new Date(m.created_at).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})}{m.sender_id===currentUser&&receipts?' · enviado':''}</small></div></div>)}{!messages.length&&<div className="chat-empty"><MessageCircle size={30}/><p>Esta conversa começou agora.</p><small>Envie a primeira mensagem.</small></div>}{typingNames.length>0&&<div className="typing-indicator"><span/><span/><span/> Alguém está digitando...</div>}<div ref={endRef}/></div><form ref={formRef} className="chat-compose" onSubmit={onSend}><textarea ref={taRef} rows={1} value={text} onChange={e=>{signalTyping(e.target.value);e.target.style.height="auto";e.target.style.height=Math.min(e.target.scrollHeight,120)+"px"}} onKeyDown={onComposerKey} placeholder="Escreva uma mensagem..." maxLength={4000} aria-label="Mensagem" enterKeyHint="enter"/><button type="submit" className="button button-primary chat-send" disabled={!text.trim()} aria-label="Enviar mensagem"><Send size={18}/></button></form></>:<div className="chat-placeholder"><div className="empty-art"><MessageCircle size={40}/></div><h3>Sua próxima conversa começa aqui.</h3><p>Escolha alguém na lista para abrir uma conversa privada.</p></div>}</section></div></>;
}
function ToastStack({toasts}:{toasts:Toast[]}) { return <div className="toast-stack" aria-live="polite">{toasts.map(t=><div key={t.id} className={`toast toast-${t.kind||'success'}`}><span>{t.kind==='error'?'!':'✓'}</span>{t.text}</div>)}</div>; }
