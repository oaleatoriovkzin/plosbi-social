-- PLOSBI SOCIAL — ETAPA 8: conta privada (seguir vira pedido que a pessoa aprova). Rode DEPOIS da etapa 7.
-- Idempotente. Quem já segue continua seguindo. Para contas PÚBLICAS nada muda.
-- LIMITE: as imagens ficam em buckets públicos; o texto e as listas são protegidos, mas quem tiver o link exato de uma foto ainda abre.

-- 1) Marca de conta privada (só o próprio dono altera, pela coluna liberada)
alter table public.profiles add column if not exists is_private boolean not null default false;
grant update (is_private) on public.profiles to authenticated;

-- 2) Pedidos para seguir
create table if not exists public.follow_requests (
  requester_id uuid not null references public.profiles(id) on delete cascade,
  target_id    uuid not null references public.profiles(id) on delete cascade,
  created_at   timestamptz not null default now(),
  primary key (requester_id, target_id),
  constraint follow_requests_not_self check (requester_id <> target_id)
);
create index if not exists follow_requests_target_idx on public.follow_requests (target_id, created_at desc);
revoke all on public.follow_requests from anon, authenticated;
grant select, insert, delete on public.follow_requests to authenticated;
alter table public.follow_requests enable row level security;

drop policy if exists ps_fr_select on public.follow_requests;
create policy ps_fr_select on public.follow_requests for select to authenticated
  using (requester_id = auth.uid() or target_id = auth.uid());
drop policy if exists ps_fr_insert on public.follow_requests;
create policy ps_fr_insert on public.follow_requests for insert to authenticated
  with check (requester_id = auth.uid() and requester_id <> target_id
    and exists (select 1 from public.profiles p where p.id = target_id and p.is_private)
    and not exists (select 1 from public.follows f where f.follower_id = requester_id and f.following_id = target_id));
drop policy if exists ps_fr_delete on public.follow_requests;
create policy ps_fr_delete on public.follow_requests for delete to authenticated
  using (requester_id = auth.uid() or target_id = auth.uid());

-- 3) Conta privada não pode ser seguida direto: só por pedido aprovado
drop policy if exists ps_follows_insert on public.follows;
create policy ps_follows_insert on public.follows for insert to authenticated
  with check (follower_id = auth.uid() and follower_id <> following_id
    and not exists (select 1 from public.profiles p where p.id = follows.following_id and p.is_private));

-- 4) Aprovar (só o dono da conta alvo)
create or replace function public.ps_approve_follow(p_requester uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.follow_requests where requester_id = p_requester and target_id = auth.uid()) then
    raise exception 'Pedido não encontrado';
  end if;
  insert into public.follows (follower_id, following_id) values (p_requester, auth.uid()) on conflict do nothing;
  delete from public.follow_requests where requester_id = p_requester and target_id = auth.uid();
end $$;
revoke all on function public.ps_approve_follow(uuid) from public, anon;
grant execute on function public.ps_approve_follow(uuid) to authenticated;

-- 5) Se a conta voltar a ser pública, os pedidos pendentes viram seguidores
create or replace function public.ps_privacy_change() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if old.is_private and not new.is_private then
    insert into public.follows (follower_id, following_id)
      select requester_id, target_id from public.follow_requests where target_id = new.id on conflict do nothing;
    delete from public.follow_requests where target_id = new.id;
  end if;
  return new;
end $$;
revoke all on function public.ps_privacy_change() from public, anon, authenticated;
drop trigger if exists ps_privacy_change on public.profiles;
create trigger ps_privacy_change after update of is_private on public.profiles
  for each row execute function public.ps_privacy_change();

-- 6) Quem pode ver publicações, comentários, curtidas e stories de conta privada: o dono e quem segue
drop policy if exists ps_posts_select on public.posts;
create policy ps_posts_select on public.posts for select to authenticated using (
  author_id = auth.uid()
  or not exists (select 1 from public.profiles p where p.id = posts.author_id and p.is_private)
  or exists (select 1 from public.follows f where f.follower_id = auth.uid() and f.following_id = posts.author_id));

drop policy if exists ps_comments_select on public.comments;
create policy ps_comments_select on public.comments for select to authenticated
  using (exists (select 1 from public.posts p where p.id = comments.post_id));   -- a regra de posts já filtra

drop policy if exists ps_likes_select on public.post_likes;
create policy ps_likes_select on public.post_likes for select to authenticated
  using (exists (select 1 from public.posts p where p.id = post_likes.post_id));

drop policy if exists ps_cr_select on public.comment_reactions;
create policy ps_cr_select on public.comment_reactions for select to authenticated
  using (exists (select 1 from public.comments c where c.id = comment_reactions.comment_id));

drop policy if exists ps_stories_select on public.stories;
create policy ps_stories_select on public.stories for select to authenticated using (
  expires_at > now() and (
    author_id = auth.uid()
    or exists (select 1 from public.follows f where f.follower_id = auth.uid() and f.following_id = stories.author_id)
    or (audience = 'everyone' and not exists (select 1 from public.profiles p where p.id = stories.author_id and p.is_private))));

-- 7) Aviso "pediu para seguir você"
alter table public.notifications drop constraint if exists notifications_type_chk;
alter table public.notifications add constraint notifications_type_chk
  check (type in ('like','comment','follow','follow_request'));

create or replace function public.ps_notify_follow_request() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.notifications (user_id, actor_id, type) values (new.target_id, new.requester_id, 'follow_request');
  return new;
exception when others then
  raise warning 'ps_notify_follow_request: %', sqlerrm; return new;
end $$;
create or replace function public.ps_unnotify_follow_request() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  delete from public.notifications where type = 'follow_request' and actor_id = old.requester_id and user_id = old.target_id;
  return old;
exception when others then
  raise warning 'ps_unnotify_follow_request: %', sqlerrm; return old;
end $$;
revoke all on function public.ps_notify_follow_request(), public.ps_unnotify_follow_request() from public, anon, authenticated;
drop trigger if exists ps_notify_follow_request on public.follow_requests;
create trigger ps_notify_follow_request after insert on public.follow_requests for each row execute function public.ps_notify_follow_request();
drop trigger if exists ps_unnotify_follow_request on public.follow_requests;
create trigger ps_unnotify_follow_request after delete on public.follow_requests for each row execute function public.ps_unnotify_follow_request();
