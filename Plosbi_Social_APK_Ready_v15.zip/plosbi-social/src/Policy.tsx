import { ArrowLeft } from 'lucide-react';

// RASCUNHO escrito a partir do que o app faz hoje. Revise (idealmente com um profissional de direito digital / LGPD) antes de divulgar.
export function PolicyScreen({ onClose }: { onClose: () => void }) {
  return (
    <div className="cm-screen" role="dialog" aria-label="Política de privacidade">
      <header className="cm-top">
        <button className="cm-back" aria-label="Voltar" onClick={onClose}><ArrowLeft size={22} /></button>
        <h2>Política de privacidade</h2>
      </header>
      <div className="policy-body">
        <p><small>Plosbi Social · desenvolvido por Kaique Oliveira · versão de outubro de 2026</small></p>
        <h3>O que guardamos</h3>
        <p>E-mail ou conta do GitHub usada no login, @, nome, bio, links, foto de perfil e fundo; publicações, imagens, comentários, curtidas, stories, mensagens, quem você segue e suas notificações.</p>
        <h3>Para que usamos</h3>
        <p>Apenas para o app funcionar: mostrar seu perfil e suas publicações para outras pessoas, entregar mensagens e avisos e manter sua conta. Não vendemos seus dados e o app não tem anúncios.</p>
        <h3>Quem pode ver o quê</h3>
        <p>Seu perfil (nome, @, foto, bio, links) e suas publicações são visíveis para quem usa o app. Stories aparecem para quem você escolher ao publicar e somem em 24 horas. Mensagens só aparecem para quem está na conversa.</p>
        <h3>Limites que você precisa saber</h3>
        <p>As mensagens ficam guardadas em servidor e <b>não têm criptografia de ponta a ponta</b>. As imagens enviadas ficam em endereços públicos: quem tiver o link exato consegue abri-las.</p>
        <h3>Onde ficam os dados</h3>
        <p>No Supabase, serviço de banco de dados e armazenamento usado pelo app.</p>
        <h3>Seus direitos</h3>
        <p>Você pode editar ou apagar seu conteúdo no app. Para pedir a exclusão da conta ou de dados, ou tirar dúvidas, fale com o desenvolvedor no Instagram <b>@okaique_dev</b>.</p>
        <p><small>Esta política pode mudar quando o app mudar, e a versão acima indica a data da última atualização.</small></p>
      </div>
    </div>
  );
}
