import { Capacitor } from '@capacitor/core';
import { Browser } from '@capacitor/browser';

// Endereços (https://… ou www.…) viram links que funcionam; no APK abrem no navegador do celular.
const URL_RE = /((?:https?:\/\/|www\.)[^\s<]+[^\s<.,;:!?)\]'"])/gi;

export function Linkify({ text }: { text: string }) {
  return (
    <>
      {text.split(URL_RE).map((part, i) => {
        if (!/^(https?:\/\/|www\.)/i.test(part)) return <span key={i}>{part}</span>;
        const href = /^www\./i.test(part) ? `https://${part}` : part;
        return (
          <a key={i} className="auto-link" href={href} target="_blank" rel="noopener noreferrer"
            onClick={e => { if (Capacitor.isNativePlatform()) { e.preventDefault(); void Browser.open({ url: href }); } }}>{part}</a>
        );
      })}
    </>
  );
}
