# Plosbi Social v6 — o que mudou (em cima do ZIP com GitHub)
FEITO: tema sólido na paleta da imagem (sem degradê/brilho/blur); borboleta azul e preta sólida; login estilo da imagem (GitHub + e-mail, mantém o login por GitHub); barra de baixo com 5 ícones (Início, Buscar, +, Mensagens, Perfil); stories de verdade (Stories.tsx: curtir 💙, quem viu, expiração, selo de verificado); removidos os repetidos: busca do topo, botão "Publicar" do cabeçalho, painel falso de "momentos", atalhos duplicados no topo (desktop).
NÃO FEITO: telas de Notificações/sino, Servidores no novo visual, Configurações no novo visual, Busca com abas, Salvos usando o banco (ainda usa o navegador), selo de verificado em posts/perfil, Reels.
NÃO TESTADO: só a sintaxe foi conferida. Sem build (npm) e sem teste no Supabase, porque o ambiente não tem internet. Rode `npm install && npm run build` e me mande qualquer erro.
SQL: etapa 2 e 3 (supabase/ da conversa) precisam estar rodadas — já estão.

# v7 — login do GitHub dentro do APK
Antes: o botão do GitHub mandava o login voltar para o SITE (https://...github.io), então o APK virava Chrome e a sessão ficava no Chrome.
Agora (só no APK): abre o navegador do sistema e volta para o app por link direto `com.plosbi.social://auth-callback`; a sessão é criada dentro do app. No site (Chrome) nada muda.
Precisa de 3 coisas fora do código: (1) plugins @capacitor/app e @capacitor/browser (já no package.json); (2) o workflow do APK inserir o intent-filter no AndroidManifest; (3) `com.plosbi.social://auth-callback` nos Redirect URLs do Supabase.
NÃO TESTADO: só sintaxe. Sem build nem teste em aparelho.

# v8 — Mensagens só com quem já tem conversa
Antes: a lista da aba Mensagens mostrava TODOS os usuários cadastrados (não eram conversas; as mensagens em si já eram protegidas pelo banco).
Agora: a lista mostra só quem já tem conversa com você. Ao digitar na busca, aparecem todos, para iniciar uma conversa nova.
NÃO TESTADO: só sintaxe. Sem build nem teste no aparelho.

# v9 — prévia e bolinha de mensagens não lidas
Lista de Mensagens: última mensagem cortada com "…", ordenada pela mais recente, e bolinha na cor de acento do tema quando há mensagem nova. Bolinha também no ícone de Mensagens da barra de baixo.
Precisa rodar supabase/etapa5_nao_lidas.sql. Sem rodar, a prévia funciona, mas a bolinha não aparece (o app não quebra).
NÃO TESTADO: só sintaxe. Sem build nem teste no aparelho.

# v10 — correções
Story: a imagem não cobre mais o botão Curtir; 💙 pequeno sobre a foto de quem curtiu. Selo de verificado no perfil, nos posts e na lista de Mensagens (o app agora carrega is_verified). Menu do perfil (três barrinhas): Configurações, Bem-estar e Sair saíram do topo. Bio mantém quebras de linha. Seletor de imagem aceita qualquer imagem (image/*).
NÃO TESTADO: só sintaxe. Causa do problema do "PNG maiúsculo" é provável, não confirmada.
