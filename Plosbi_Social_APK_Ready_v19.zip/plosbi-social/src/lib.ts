import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;
export const hasSupabaseConfig = Boolean(url && key && !url.includes('YOUR_PROJECT') && !key.includes('YOUR_SUPABASE'));
export const siteUrl = (import.meta.env.VITE_SITE_URL as string | undefined) || undefined;
export const supabase = hasSupabaseConfig ? createClient(url!, key!, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
}) : null;

export type Profile = { id: string; username: string; display_name: string | null; bio: string | null; avatar_url: string | null; created_at?: string; is_verified?: boolean; banner_url?: string | null; links?: string[] | null };
export type Post = { id: string; author_id: string; content: string | null; media_url: string | null; created_at: string };
export type Comment = { id: string; post_id: string; author_id: string; content: string; created_at: string };
export type Message = { id: string; conversation_id: string; sender_id: string; content: string; created_at: string; media_url?: string | null; media_type?: 'image' | 'video' | null; ref?: string | null };

export function friendlyError(error: unknown): string {
  const raw = error as { message?: unknown } | null;
  const message = error instanceof Error ? error.message : (raw && typeof raw === 'object' && raw.message ? String(raw.message) : String(error ?? 'Erro desconhecido'));
  if (/Invalid login credentials/i.test(message)) return 'E-mail ou senha incorretos.';
  if (/Email not confirmed/i.test(message)) return 'Confirme seu e-mail antes de entrar.';
  if (/User already registered/i.test(message)) return 'Este e-mail já tem uma conta. Tente entrar.';
  if (/Failed to fetch|fetch failed|NetworkError/i.test(message)) return 'Sem conexão com o Supabase. Confira a internet e as variáveis do .env.';
  if (/bucket not found/i.test(message)) return 'O armazenamento de imagens (bucket) não existe no Supabase. Rode o SQL da etapa 1.';
  if (/exceeded the maximum allowed size|payload too large/i.test(message)) return 'A imagem é maior que o limite permitido pelo bucket.';
  if (/mime type|not supported/i.test(message)) return 'Formato de imagem não permitido pelo bucket (use JPG, PNG ou WebP).';
  if (/row-level security|violates row-level security/i.test(message)) return 'O banco bloqueou esta ação pelas regras de segurança (RLS). Confira as políticas do Supabase.';
  return message;
}

export function initials(profile?: Partial<Profile> | null) {
  const label = profile?.display_name || profile?.username || '?';
  return label.split(/[\s._-]+/).filter(Boolean).slice(0, 2).map(s => s[0]?.toUpperCase()).join('') || '?';
}

export function timeAgo(date: string) {
  const seconds = Math.max(0, Math.floor((Date.now() - new Date(date).getTime()) / 1000));
  if (seconds < 60) return 'agora';
  if (seconds < 3600) return `${Math.floor(seconds / 60)} min`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)} h`;
  return `${Math.floor(seconds / 86400)} d`;
}

/** Reduz fotos grandes (câmera do celular) e converte para JPEG antes do upload. */
export async function resizeImage(file: File, max: number, square: boolean): Promise<Blob> {
  let bitmap: ImageBitmap | HTMLImageElement;
  try { bitmap = await createImageBitmap(file); }
  catch {
    try {
      bitmap = await new Promise<HTMLImageElement>((ok, no) => {
        const u = URL.createObjectURL(file); const im = new Image();
        im.onload = () => { URL.revokeObjectURL(u); ok(im); };
        im.onerror = () => { URL.revokeObjectURL(u); no(new Error('decode')); };
        im.src = u;
      });
    } catch { throw new Error('Não foi possível ler esta imagem. Tente outra foto em JPG, PNG ou WebP.'); }
  }
  const bw = 'naturalWidth' in bitmap ? bitmap.naturalWidth : bitmap.width;
  const bh = 'naturalHeight' in bitmap ? bitmap.naturalHeight : bitmap.height;
  const side = Math.min(bw, bh);
  const sw = square ? side : bw, sh = square ? side : bh;
  const scale = Math.min(1, max / Math.max(sw, sh));
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(sw * scale); canvas.height = Math.round(sh * scale);
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Não foi possível processar a imagem neste aparelho.');
  ctx.drawImage(bitmap, (bw - sw) / 2, (bh - sh) / 2, sw, sh, 0, 0, canvas.width, canvas.height);
  if ('close' in bitmap) bitmap.close();
  return await new Promise<Blob>((resolve, reject) => canvas.toBlob(b => b ? resolve(b) : reject(new Error('Falha ao converter a imagem.')), 'image/jpeg', 0.85));
}

// Aceita a imagem pelo tipo OU pela extensão (alguns celulares mandam o tipo vazio ou em maiúsculas)
export function isImageFile(file: File): boolean {
  if (/^image\//i.test(file.type)) return true;
  if (/\.(jpe?g|png|webp|gif|heic|heif|avif|bmp)$/i.test(file.name)) return true;
  return file.type === '' || file.type === 'application/octet-stream';   // tipo desconhecido: a leitura da imagem decide
}
