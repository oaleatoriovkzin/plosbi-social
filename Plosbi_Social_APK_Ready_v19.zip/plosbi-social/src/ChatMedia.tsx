import { useEffect, useState } from 'react';
import { supabase, resizeImage, isImageFile, friendlyError } from './lib';
import './chatmedia.css';

const MB = 1024 * 1024;

// Mostra a foto/vídeo de uma mensagem. Caminho do bucket privado => pede um link temporário; endereço https => usa direto.
export function ChatMedia({ url, type, story }: { url: string; type: 'image' | 'video'; story?: boolean }) {
  const direct = /^https?:\/\//i.test(url);
  const [src, setSrc] = useState<string | null>(direct ? url : null);
  const [big, setBig] = useState(false);
  useEffect(() => {
    if (direct || !supabase) return;
    let off = false;
    void supabase.storage.from('chat-media').createSignedUrl(url, 3600).then(({ data }) => { if (!off) setSrc(data?.signedUrl ?? ''); });
    return () => { off = true; };
  }, [url, direct]);
  if (src === null) return <div className="cmed cmed-load" aria-busy="true" />;
  if (!src) return <div className="cmed cmed-err">Mídia indisponível</div>;
  if (type === 'video') return <video className="cmed" src={src} controls playsInline preload="metadata" />;
  return (
    <>
      <img className={`cmed${story ? ' cmed-story' : ''}`} src={src} alt={story ? 'Story' : 'Foto enviada'} loading="lazy" onClick={() => !story && setBig(true)} />
      {story && <span className="cmed-tag">Story</span>}
      {big && <div className="cmed-big" role="dialog" aria-label="Foto" onClick={() => setBig(false)}><img src={src} alt="Foto enviada" /></div>}
    </>
  );
}

function shortEnough(file: File): Promise<boolean> {
  return new Promise(ok => {
    const v = document.createElement('video'); const u = URL.createObjectURL(file);
    v.preload = 'metadata';
    v.onloadedmetadata = () => { URL.revokeObjectURL(u); ok(!isFinite(v.duration) || v.duration <= 61); };
    v.onerror = () => { URL.revokeObjectURL(u); ok(true); };
    v.src = u;
  });
}

// Envia foto ou vídeo para a conversa. Devolve o texto do erro, ou null se deu certo.
export async function sendMediaMessage(file: File, conversationId: string, meId: string, caption: string): Promise<string | null> {
  if (!supabase) return 'Sem conexão com o servidor.';
  const isVideo = /^video\//i.test(file.type) || /\.(mp4|webm|mov|m4v|3gp)$/i.test(file.name);
  if (!isVideo && !isImageFile(file)) return 'Escolha uma foto ou um vídeo.';
  if (isVideo && file.size > 25 * MB) return 'O vídeo pode ter no máximo 25 MB.';
  try {
    let body: Blob = file; let ext = 'jpg'; let ct = 'image/jpeg';
    if (isVideo) {
      if (!(await shortEnough(file))) return 'O vídeo pode ter no máximo 60 segundos.';
      ext = (file.name.split('.').pop() || 'mp4').toLowerCase(); ct = file.type || 'video/mp4';
    } else if (/gif$/i.test(file.type) || /\.gif$/i.test(file.name)) {
      if (file.size > 8 * MB) return 'O GIF pode ter no máximo 8 MB.';
      ext = 'gif'; ct = 'image/gif';
    } else body = await resizeImage(file, 1600, false);
    const path = `${conversationId}/${crypto.randomUUID()}.${ext}`;
    const up = await supabase.storage.from('chat-media').upload(path, body, { contentType: ct, upsert: false });
    if (up.error) throw up.error;
    const { error } = await supabase.from('messages').insert({
      conversation_id: conversationId, sender_id: meId,
      content: caption.trim() || (isVideo ? '🎬 Vídeo' : '📷 Foto'), media_url: path, media_type: isVideo ? 'video' : 'image'
    });
    if (error) throw error;
    return null;
  } catch (e) { return `Mensagem de mídia: ${friendlyError(e)}`; }
}
