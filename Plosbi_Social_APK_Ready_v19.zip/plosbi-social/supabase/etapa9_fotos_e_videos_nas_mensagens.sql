-- PLOSBI SOCIAL — ETAPA 9: fotos e vídeos nas mensagens (+ miniatura do story nas respostas). Rode DEPOIS da etapa 8.
-- Aditivo e idempotente. As mídias das conversas ficam num bucket PRIVADO: só quem está na conversa consegue abrir.

-- 1) Campos novos na mensagem (o texto continua obrigatório: foto/vídeo levam "📷 Foto" / "🎬 Vídeo" ou a legenda)
alter table public.messages add column if not exists media_url  text;   -- caminho no bucket privado, ou endereço https (miniatura de story)
alter table public.messages add column if not exists media_type text;   -- 'image' ou 'video'
alter table public.messages add column if not exists ref        text;   -- 'story' quando é resposta/reação a um story
do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'ps_messages_media_chk' and conrelid = 'public.messages'::regclass) then
    alter table public.messages add constraint ps_messages_media_chk check (
      (media_type is null or media_type in ('image','video'))
      and (ref is null or ref = 'story')
      and (media_url is null or char_length(media_url) <= 500)) not valid;
  end if;
end $$;

-- 2) Bucket privado "chat-media": 25 MB por arquivo, imagens e vídeos comuns
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('chat-media', 'chat-media', false, 26214400,
        array['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','video/quicktime','video/3gpp'])
on conflict (id) do update
  set public = false, file_size_limit = 26214400, allowed_mime_types = excluded.allowed_mime_types;

-- 3) Caminho = <id da conversa>/<arquivo>. Só quem é membro da conversa envia e abre.
drop policy if exists ps_chatmedia_select on storage.objects;
create policy ps_chatmedia_select on storage.objects for select to authenticated
  using (bucket_id = 'chat-media' and exists (
    select 1 from public.conversation_members m
    where m.conversation_id::text = (storage.foldername(name))[1] and m.user_id = auth.uid()));

drop policy if exists ps_chatmedia_insert on storage.objects;
create policy ps_chatmedia_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'chat-media' and exists (
    select 1 from public.conversation_members m
    where m.conversation_id::text = (storage.foldername(name))[1] and m.user_id = auth.uid()));
-- (sem política de apagar: por enquanto o app não apaga mídia de conversa)
