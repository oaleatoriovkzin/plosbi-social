-- PLOSBI SOCIAL — ETAPA 6: comentários (responder, curtir/não curtir, fixar, apagar). Rode DEPOIS da etapa 5.
-- Aditivo e idempotente. Não apaga comentários existentes.

-- 1) Respostas e comentário fixado
alter table public.comments add column if not exists parent_id uuid references public.comments(id) on delete cascade;
alter table public.comments add column if not exists pinned boolean not null default false;
create index if not exists comments_parent_idx on public.comments (parent_id);

-- Antes de gravar: a resposta tem de ser do MESMO post; resposta de resposta vira resposta do comentário principal;
-- e o app nunca cria comentário já fixado.
create or replace function public.ps_comment_parent_check() returns trigger
language plpgsql set search_path = public as $$
declare p record;
begin
  if new.parent_id is not null then
    select post_id, parent_id into p from public.comments where id = new.parent_id;
    if not found or p.post_id <> new.post_id then raise exception 'Resposta inválida'; end if;
    if p.parent_id is not null then new.parent_id := p.parent_id; end if;
  end if;
  new.pinned := false;
  return new;
end $$;
drop trigger if exists ps_comment_parent_check on public.comments;
create trigger ps_comment_parent_check before insert on public.comments
  for each row execute function public.ps_comment_parent_check();

-- 2) Só quem publicou o post fixa comentários (um fixado por post)
create or replace function public.ps_pin_comment(p_comment uuid, p_pin boolean) returns void
language plpgsql security definer set search_path = public as $$
declare c record;
begin
  select cm.post_id, cm.parent_id, po.author_id as owner into c
  from public.comments cm join public.posts po on po.id = cm.post_id where cm.id = p_comment;
  if not found or c.owner <> auth.uid() then raise exception 'Sem permissão'; end if;
  if c.parent_id is not null then raise exception 'Só dá para fixar comentários principais'; end if;
  if p_pin then update public.comments set pinned = false where post_id = c.post_id and pinned; end if;
  update public.comments set pinned = p_pin where id = p_comment;
end $$;
revoke all on function public.ps_pin_comment(uuid, boolean) from public, anon;
grant execute on function public.ps_pin_comment(uuid, boolean) to authenticated;

-- 3) Quem publicou o post também pode apagar comentários dele (o autor do comentário já podia)
drop policy if exists ps_comments_delete_post_owner on public.comments;
create policy ps_comments_delete_post_owner on public.comments for delete to authenticated
  using (exists (select 1 from public.posts p where p.id = comments.post_id and p.author_id = auth.uid()));

-- 4) Curtir / não curtir comentário
create table if not exists public.comment_reactions (
  comment_id uuid not null references public.comments(id) on delete cascade,
  user_id    uuid not null references public.profiles(id) on delete cascade,
  kind       text not null check (kind in ('like','dislike')),
  created_at timestamptz not null default now(),
  primary key (comment_id, user_id)
);
create index if not exists comment_reactions_user_idx on public.comment_reactions (user_id);
revoke all on public.comment_reactions from anon, authenticated;
grant select, insert, update, delete on public.comment_reactions to authenticated;
alter table public.comment_reactions enable row level security;

drop policy if exists ps_cr_select on public.comment_reactions;
create policy ps_cr_select on public.comment_reactions for select to authenticated using (true);
drop policy if exists ps_cr_insert on public.comment_reactions;
create policy ps_cr_insert on public.comment_reactions for insert to authenticated with check (user_id = auth.uid());
drop policy if exists ps_cr_update on public.comment_reactions;
create policy ps_cr_update on public.comment_reactions for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists ps_cr_delete on public.comment_reactions;
create policy ps_cr_delete on public.comment_reactions for delete to authenticated using (user_id = auth.uid());
