-- PLOSBI SOCIAL — ETAPA 5: mensagens não lidas (bolinha na lista de Mensagens). Rode DEPOIS da etapa 4.
-- Aditivo e idempotente. Guarda, para cada pessoa em cada conversa, até que horário ela já leu.

-- Conversas que já existem entram como "lidas" (o padrão é o momento em que você rodar este SQL).
alter table public.conversation_members add column if not exists last_read_at timestamptz not null default now();

-- O app NÃO edita a tabela direto: marca como lido por esta função, que usa o relógio do servidor
-- e só mexe na SUA linha.
create or replace function public.ps_mark_read(p_conversation uuid) returns void
language sql security definer set search_path = public as $$
  update public.conversation_members set last_read_at = now()
  where conversation_id = p_conversation and user_id = auth.uid();
$$;
revoke all on function public.ps_mark_read(uuid) from public, anon;
grant execute on function public.ps_mark_read(uuid) to authenticated;
