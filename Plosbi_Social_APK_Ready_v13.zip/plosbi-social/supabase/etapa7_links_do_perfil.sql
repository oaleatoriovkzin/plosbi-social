-- PLOSBI SOCIAL — ETAPA 7: links no perfil (até 3). Rode DEPOIS da etapa 6. Aditivo e idempotente.
alter table public.profiles add column if not exists links text[] not null default '{}';

-- cada link precisa começar com http:// ou https://, sem espaços
create or replace function public.ps_links_ok(l text[]) returns boolean
language sql immutable as $$
  select coalesce(bool_and(x ~* '^https?://[^[:space:]]{3,200}$'), true) from unnest(l) as x
$$;

do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'profiles_links_chk' and conrelid = 'public.profiles'::regclass) then
    alter table public.profiles add constraint profiles_links_chk
      check (cardinality(links) <= 3 and public.ps_links_ok(links)) not valid;
  end if;
end $$;

-- a etapa 1 liberou a edição só de algumas colunas: libera também os links
grant update (links) on public.profiles to authenticated;
