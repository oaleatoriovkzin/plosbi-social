import { useCallback, useEffect, useRef, useState } from 'react';
import type { FormEvent } from 'react';
import { ArrowLeft, Pin, Send, ThumbsDown, ThumbsUp, Trash2, X } from 'lucide-react';
import { supabase, timeAgo, friendlyError } from './lib';
import type { Post } from './lib';
import { VerifiedBadge } from './VerifiedBadge';
import './comments.css';

type C = { id: string; post_id: string; author_id: string; content: string; created_at: string; parent_id: string | null; pinned: boolean };
type P = { id: string; username: string; display_name: string | null; avatar_url: string | null; is_verified: boolean };
type R = { comment_id: string; user_id: string; kind: 'like' | 'dislike' };
type Say = (text: string, kind?: 'error' | 'success') => void;

function Face({ p }: { p?: P }) {
  const n = (p?.display_name || p?.username || '?').slice(0, 1).toUpperCase();
  return p?.avatar_url ? <img className="st-pic cm-face" src={p.avatar_url} alt="" /> : <span className="st-pic st-pic-empty cm-face">{n}</span>;
}

export function CommentsScreen({ post, ownerId, meId, notify, onClose, onChanged }: {
  post: Post; ownerId: string; meId: string; notify: Say; onClose: () => void; onChanged: () => void;
}) {
  const [list, setList] = useState<C[]>([]);
  const [people, setPeople] = useState<Record<string, P>>({});
  const [reactions, setReactions] = useState<R[]>([]);
  const [loading, setLoading] = useState(true);
  const [text, setText] = useState('');
  const [replyTo, setReplyTo] = useState<C | null>(null);
  const [leaving, setLeaving] = useState<string | null>(null);
  const [sent, setSent] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const isOwner = ownerId === meId;

  const load = useCallback(async () => {
    if (!supabase) return;
    let res: any = await supabase.from('comments').select('id,post_id,author_id,content,created_at,parent_id,pinned').eq('post_id', post.id).order('created_at', { ascending: true });
    if (res.error) res = await supabase.from('comments').select('id,post_id,author_id,content,created_at').eq('post_id', post.id).order('created_at', { ascending: true });
    if (res.error) { notify(friendlyError(res.error), 'error'); setLoading(false); return; }
    const cs = ((res.data ?? []) as any[]).map(c => ({ ...c, parent_id: c.parent_id ?? null, pinned: !!c.pinned })) as C[];
    const ids = cs.map(c => c.id);
    const who = Array.from(new Set([...cs.map(c => c.author_id), meId]));
    const [pr, rx] = await Promise.all([
      supabase.from('profiles').select('id,username,display_name,avatar_url,is_verified').in('id', who),
      ids.length ? supabase.from('comment_reactions').select('comment_id,user_id,kind').in('comment_id', ids) : Promise.resolve({ data: [] as R[] })
    ]);
    setList(cs);
    setPeople(Object.fromEntries(((pr.data ?? []) as P[]).map(p => [p.id, p])));
    setReactions((rx.data ?? []) as R[]);
    setLoading(false);
  }, [post.id, meId, notify]);
  useEffect(() => { void load(); }, [load]);

  const mine = (id: string) => reactions.find(r => r.comment_id === id && r.user_id === meId)?.kind;
  const count = (id: string, k: 'like' | 'dislike') => reactions.filter(r => r.comment_id === id && r.kind === k).length;
  const ownerLiked = (id: string) => reactions.some(r => r.comment_id === id && r.user_id === ownerId && r.kind === 'like');
  const nameOf = (id: string) => people[id]?.display_name || people[id]?.username || 'Pessoa';

  async function react(id: string, kind: 'like' | 'dislike') {
    if (!supabase) return;
    const had = mine(id); const before = reactions;
    setReactions(prev => { const rest = prev.filter(r => !(r.comment_id === id && r.user_id === meId)); return had === kind ? rest : [...rest, { comment_id: id, user_id: meId, kind }]; });
    const { error } = had === kind
      ? await supabase.from('comment_reactions').delete().eq('comment_id', id).eq('user_id', meId)
      : await supabase.from('comment_reactions').upsert({ comment_id: id, user_id: meId, kind }, { onConflict: 'comment_id,user_id' });
    if (error) { setReactions(before); notify(friendlyError(error), 'error'); }
  }

  async function send(e: FormEvent) {
    e.preventDefault();
    const t = text.trim();
    if (!supabase || !t) return;
    const row: Record<string, unknown> = { post_id: post.id, author_id: meId, content: t };
    if (replyTo) row.parent_id = replyTo.parent_id ?? replyTo.id;
    const { error } = await supabase.from('comments').insert(row);
    if (error) { notify(friendlyError(error), 'error'); return; }
    setText(''); setReplyTo(null); setSent(n => n + 1);
    await load(); onChanged();
  }

  async function remove(c: C) {
    if (!supabase) return;
    setLeaving(c.id);
    const { error } = await supabase.from('comments').delete().eq('id', c.id);
    window.setTimeout(async () => { setLeaving(null); if (error) notify(friendlyError(error), 'error'); await load(); onChanged(); }, 280);
  }

  async function pin(c: C) {
    if (!supabase) return;
    const { error } = await supabase.rpc('ps_pin_comment', { p_comment: c.id, p_pin: !c.pinned });
    if (error) notify(friendlyError(error), 'error'); else await load();
  }

  function startReply(c: C) {
    setReplyTo(c);
    const u = people[c.author_id]?.username;
    if (u) setText(t => t || `@${u} `);
    inputRef.current?.focus();
  }

  function row(c: C, isReply: boolean) {
    const p = people[c.author_id]; const my = mine(c.id);
    const likes = count(c.id, 'like'); const dislikes = count(c.id, 'dislike');
    return (
      <li key={c.id} className={`cm-item${isReply ? ' cm-reply' : ''}${leaving === c.id ? ' cm-leaving' : ''}`}>
        <Face p={p} />
        <div className="cm-main">
          <div className="cm-head">
            <b>{nameOf(c.author_id)}</b>{p?.is_verified && <VerifiedBadge size={13} />}
            {ownerLiked(c.id) && <span className="cm-owner-like" title="Curtido por quem publicou" aria-label="Curtido por quem publicou">💙</span>}
            <small>{timeAgo(c.created_at)}</small>
            {c.pinned && <span className="cm-pinned"><Pin size={12} /> Fixado</span>}
          </div>
          <p className="cm-text">{c.content}</p>
          <div className="cm-actions">
            <button className={my === 'like' ? 'on' : ''} aria-pressed={my === 'like'} aria-label="Curtir comentário" onClick={() => void react(c.id, 'like')}><ThumbsUp size={18} /><span>{likes || ''}</span></button>
            <button className={my === 'dislike' ? 'on' : ''} aria-pressed={my === 'dislike'} aria-label="Não curtir comentário" onClick={() => void react(c.id, 'dislike')}><ThumbsDown size={18} /><span>{dislikes || ''}</span></button>
            <button onClick={() => startReply(c)}>Responder</button>
            {isOwner && !isReply && <button aria-label={c.pinned ? 'Desafixar comentário' : 'Fixar comentário'} onClick={() => void pin(c)}><Pin size={18} /></button>}
            {(c.author_id === meId || isOwner) && <button className="danger" aria-label="Apagar comentário" onClick={() => void remove(c)}><Trash2 size={18} /></button>}
          </div>
        </div>
      </li>
    );
  }

  const top = list.filter(c => !c.parent_id).sort((a, b) => Number(b.pinned) - Number(a.pinned));
  return (
    <div className="cm-screen" role="dialog" aria-label="Comentários">
      <header className="cm-top">
        <button className="cm-back" aria-label="Voltar" onClick={onClose}><ArrowLeft size={22} /></button>
        <h2>Comentários{list.length ? ` (${list.length})` : ''}</h2>
      </header>
      <ul className="cm-list">
        {loading && <li className="cm-empty">Carregando…</li>}
        {!loading && top.length === 0 && <li className="cm-empty">Nenhum comentário ainda. Seja a primeira pessoa!</li>}
        {top.map(c => (
          <div key={c.id}>
            {row(c, false)}
            {list.filter(r => r.parent_id === c.id).map(r => row(r, true))}
          </div>
        ))}
      </ul>
      {replyTo && <div className="cm-replying">Respondendo a <b>{nameOf(replyTo.author_id)}</b><button aria-label="Cancelar resposta" onClick={() => { setReplyTo(null); setText(''); }}><X size={16} /></button></div>}
      <form className="cm-form" onSubmit={e => void send(e)}>
        <input ref={inputRef} value={text} maxLength={1000} onChange={e => setText(e.target.value)} placeholder="Adicione um comentário..." />
        <button className="cm-send" disabled={!text.trim()} aria-label="Enviar comentário"><span key={sent} className={sent > 0 ? 'cm-plane cm-fly' : 'cm-plane'}><Send size={20} /></span></button>
      </form>
    </div>
  );
}
