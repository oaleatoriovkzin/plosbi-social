import { useMemo, useState } from 'react';
import { Check, Copy, Download, LoaderCircle, Send, Share2, X } from 'lucide-react';
import { Capacitor } from '@capacitor/core';
import { Share } from '@capacitor/share';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { supabase, siteUrl, friendlyError } from './lib';
import type { Post, Profile } from './lib';
import './share.css';

type Say = (text: string, kind?: 'error' | 'success') => void;
type SaveState = 'idle' | 'busy' | 'done' | 'fail';

export function ShareSheet({ post, author, meId, profiles, partners, notify, onClose }: {
  post: Post; author?: Profile; meId: string; profiles: Profile[]; partners: string[]; notify: Say; onClose: () => void;
}) {
  const [q, setQ] = useState('');
  const [sentTo, setSentTo] = useState<string[]>([]);
  const [busy, setBusy] = useState<string | null>(null);
  const [save, setSave] = useState<SaveState>('idle');
  const who = author?.display_name || author?.username || 'Plosbi';
  const body = (post.content || '').trim();
  const text = `${who}${author?.username ? ` (@${author.username})` : ''}: ${body ? body.slice(0, 280) : 'Publicação'}`;
  const link = post.media_url || siteUrl || window.location.href;

  const people = useMemo(() => {
    const t = q.trim().toLowerCase();
    const base = t ? profiles : profiles.filter(p => partners.includes(p.id));
    return base.filter(p => `${p.username} ${p.display_name || ''}`.toLowerCase().includes(t)).slice(0, 30);
  }, [q, profiles, partners]);

  async function sendTo(p: Profile) {
    if (!supabase || busy || sentTo.includes(p.id)) return;
    setBusy(p.id);
    try {
      const dm = await supabase.rpc('ps_get_or_create_dm', { p_other: p.id });
      if (dm.error) throw dm.error;
      const { error } = await supabase.from('messages').insert({ conversation_id: dm.data, sender_id: meId, content: `${text}\n${link}`.slice(0, 1000) });
      if (error) throw error;
      setSentTo(prev => [...prev, p.id]);
    } catch (e) { notify(friendlyError(e as any), 'error'); } finally { setBusy(null); }
  }

  async function viaOtherApp() {
    try {
      if (Capacitor.isNativePlatform()) await Share.share({ title: 'Plosbi', text, url: link, dialogTitle: 'Compartilhar' });
      else if (navigator.share) await navigator.share({ title: 'Plosbi', text, url: link });
      else { await navigator.clipboard.writeText(`${text}\n${link}`); notify('Este navegador não abre o compartilhamento. Texto copiado!'); }
    } catch (e) { if ((e as Error)?.name !== 'AbortError') notify(friendlyError(e as any), 'error'); }
  }

  async function copy() {
    try { await navigator.clipboard.writeText(`${text}\n${link}`); notify('Texto copiado!'); }
    catch { notify('Não foi possível copiar.', 'error'); }
  }

  async function savePhoto() {
    if (!post.media_url || save === 'busy') return;
    setSave('busy');
    try {
      const res = await fetch(post.media_url);
      if (!res.ok) throw new Error('Não foi possível baixar a imagem.');
      const blob = await res.blob();
      const ext = (blob.type.split('/')[1] || 'jpg').replace('jpeg', 'jpg').split('+')[0];
      const name = `plosbi-${Date.now()}.${ext}`;
      if (Capacitor.isNativePlatform()) {
        const data = await new Promise<string>((ok, no) => { const r = new FileReader(); r.onload = () => ok(String(r.result).split(',')[1] || ''); r.onerror = () => no(r.error); r.readAsDataURL(blob); });
        const f = await Filesystem.writeFile({ path: name, data, directory: Directory.Cache });
        await Share.share({ files: [f.uri], dialogTitle: 'Salvar foto' });
      } else {
        const a = document.createElement('a'); const u = URL.createObjectURL(blob);
        a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove();
        window.setTimeout(() => URL.revokeObjectURL(u), 4000);
      }
      setSave('done');
    } catch (e) { setSave('fail'); notify(friendlyError(e as any), 'error'); }
    window.setTimeout(() => setSave('idle'), 2200);
  }

  return (
    <div className="sh-backdrop" onClick={onClose}>
      <div className="sh-sheet" role="dialog" aria-label="Compartilhar" onClick={e => e.stopPropagation()}>
        <div className="sh-head"><h3>Compartilhar</h3><button className="sh-x" aria-label="Fechar" onClick={onClose}><X size={20} /></button></div>
        <div className="sh-actions">
          <button onClick={() => void viaOtherApp()}><Share2 size={22} /><span>Outros apps</span></button>
          <button onClick={() => void copy()}><Copy size={22} /><span>Copiar texto</span></button>
          {post.media_url && (
            <button className={`sh-save sh-${save}`} onClick={() => void savePhoto()} disabled={save === 'busy'}>
              {save === 'done' ? <Check size={22} className="sh-pop" /> : save === 'fail' ? <X size={22} className="sh-pop" /> : save === 'busy' ? <LoaderCircle size={22} className="sh-spin" /> : <Download size={22} />}
              <span>{save === 'done' ? 'Pronto!' : save === 'busy' ? 'Baixando…' : 'Salvar foto'}</span>
            </button>
          )}
        </div>
        <input className="sh-search" value={q} onChange={e => setQ(e.target.value)} placeholder="Enviar para uma pessoa…" aria-label="Buscar pessoa" />
        <ul className="sh-people">
          {people.length === 0 && <li className="sh-empty">{q.trim() ? 'Ninguém encontrado.' : 'Digite um nome para achar alguém, ou converse com alguém primeiro.'}</li>}
          {people.map(p => (
            <li key={p.id}>
              {p.avatar_url ? <img className="st-pic sh-face" src={p.avatar_url} alt="" /> : <span className="st-pic st-pic-empty sh-face">{(p.display_name || p.username).slice(0, 1).toUpperCase()}</span>}
              <span className="sh-name"><b>{p.display_name || p.username}</b><small>@{p.username}</small></span>
              <button className={sentTo.includes(p.id) ? 'sh-sent' : ''} disabled={busy === p.id || sentTo.includes(p.id)} onClick={() => void sendTo(p)} aria-label={`Enviar para ${p.display_name || p.username}`}>
                {sentTo.includes(p.id) ? <><Check size={18} className="sh-pop" /> Enviado</> : busy === p.id ? <LoaderCircle size={18} className="sh-spin" /> : <><Send size={18} /> Enviar</>}
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
