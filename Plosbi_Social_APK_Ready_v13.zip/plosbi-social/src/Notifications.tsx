import { useCallback, useEffect, useState } from 'react';
import { supabase, timeAgo, friendlyError } from './lib';
import type { Profile } from './lib';
import { VerifiedBadge } from './VerifiedBadge';
import './notifications.css';

type N = { id: string; actor_id: string; type: 'like' | 'comment' | 'follow'; post_id: string | null; read_at: string | null; created_at: string };
type Tab = 'all' | 'like' | 'comment' | 'follow';
const TABS: { id: Tab; label: string }[] = [{ id: 'all', label: 'Todas' }, { id: 'like', label: 'Curtidas' }, { id: 'comment', label: 'Comentários' }, { id: 'follow', label: 'Seguidores' }];
const TEXT: Record<N['type'], string> = { like: 'curtiu sua publicação', comment: 'comentou na sua publicação', follow: 'começou a seguir você' };

export function NotificationsPage({ meId, profiles, onOpenProfile, onOpenPost, notify, onRead }: {
  meId: string; profiles: Record<string, Profile>; onOpenProfile: (p: Profile) => void; onOpenPost: (postId: string) => void;
  notify: (text: string, kind?: 'error' | 'success') => void; onRead: () => void;
}) {
  const [items, setItems] = useState<N[] | null>(null);
  const [tab, setTab] = useState<Tab>('all');

  const load = useCallback(async () => {
    if (!supabase) return;
    const { data, error } = await supabase.from('notifications').select('id,actor_id,type,post_id,read_at,created_at')
      .eq('user_id', meId).order('created_at', { ascending: false }).limit(100);
    if (error) { notify(friendlyError(error), 'error'); setItems([]); return; }
    setItems((data ?? []) as N[]);
  }, [meId, notify]);
  useEffect(() => { void load(); }, [load]);

  useEffect(() => {
    const sb = supabase;
    if (!sb || !items || !items.some(n => !n.read_at)) return;
    const t = window.setTimeout(async () => {
      await sb.from('notifications').update({ read_at: new Date().toISOString() }).eq('user_id', meId).is('read_at', null);
      onRead();
    }, 1500);
    return () => window.clearTimeout(t);
  }, [items, meId, onRead]);

  const shown = (items ?? []).filter(n => tab === 'all' || n.type === tab);
  return (
    <section className="nt-page">
      <h1 className="nt-title">Notificações</h1>
      <div className="nt-tabs" role="tablist">
        {TABS.map(t => <button key={t.id} role="tab" aria-selected={tab === t.id} className={tab === t.id ? 'on' : ''} onClick={() => setTab(t.id)}>{t.label}</button>)}
      </div>
      <ul className="nt-list">
        {items === null && <li className="nt-empty">Carregando…</li>}
        {items !== null && shown.length === 0 && <li className="nt-empty">Nada por aqui ainda.</li>}
        {shown.map(n => {
          const p = profiles[n.actor_id]; const name = p?.display_name || p?.username || 'Alguém';
          const open = () => { if (n.type !== 'follow' && n.post_id) onOpenPost(n.post_id); else if (p) onOpenProfile(p); };
          return (
            <li key={n.id}>
              <button className="nt-row" onClick={open}>
                {p?.avatar_url ? <img className="st-pic nt-face" src={p.avatar_url} alt="" /> : <span className="st-pic st-pic-empty nt-face">{name.slice(0, 1).toUpperCase()}</span>}
                <span className="nt-text"><b>{name}</b>{p?.is_verified && <> <VerifiedBadge size={13} /></>} {TEXT[n.type]}<small>{timeAgo(n.created_at)}</small></span>
                {!n.read_at && <i className="unread-dot" aria-label="Não lida" />}
              </button>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
