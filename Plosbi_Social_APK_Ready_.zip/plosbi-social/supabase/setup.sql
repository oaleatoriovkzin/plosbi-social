-- Butterfly Social setup for the existing Plosbi schema.
-- Read first, back up the project, and run in Supabase SQL Editor as project owner.
-- Creates/replaces only objects explicitly named butterfly_v1_* or ps_* below.
-- It does not drop or recreate user tables or delete rows.

create unique index if not exists profiles_username_lower_uq on public.profiles (lower(username));
create unique index if not exists follows_uq on public.follows (follower_id, following_id);
create unique index if not exists post_likes_uq on public.post_likes (post_id, user_id);
create unique index if not exists server_members_uq on public.server_members (server_id, user_id);
create unique index if not exists conv_members_uq on public.conversation_members (conversation_id, user_id);
create unique index if not exists server_invites_code_uq on public.server_invites (lower(code));
create index if not exists posts_created_idx on public.posts (created_at desc);
create index if not exists posts_author_created_idx on public.posts (author_id, created_at desc);
create index if not exists comments_post_idx on public.comments (post_id, created_at);
create index if not exists messages_conv_idx on public.messages (conversation_id, created_at);

create or replace function public.ps_is_conv_member(cid uuid) returns boolean
language sql stable security definer set search_path = public, auth as $$
  select exists (select 1 from public.conversation_members where conversation_id = cid and user_id = auth.uid());
$$;
create or replace function public.ps_is_server_member(sid uuid) returns boolean
language sql stable security definer set search_path = public, auth as $$
  select exists (select 1 from public.server_members where server_id = sid and user_id = auth.uid());
$$;
create or replace function public.ps_is_server_admin(sid uuid) returns boolean
language sql stable security definer set search_path = public, auth as $$
  select exists (select 1 from public.server_members where server_id = sid and user_id = auth.uid() and role in ('owner','admin'));
$$;

create or replace function public.ps_handle_new_user() returns trigger
language plpgsql security definer set search_path = public, auth as $$
declare u text; d text;
begin
  u := left(regexp_replace(lower(coalesce(new.raw_user_meta_data->>'username', split_part(coalesce(new.email,''),'@',1))), '[^a-z0-9._]', '', 'g'), 24);
  if char_length(u) < 3 then u := 'user' || substr(md5(new.id::text), 1, 6); end if;
  d := left(coalesce(nullif(new.raw_user_meta_data->>'display_name',''), u), 50);
  begin
    insert into public.profiles (id, username, display_name) values (new.id, u, d) on conflict (id) do nothing;
  exception when unique_violation then
    insert into public.profiles (id, username, display_name) values (new.id, left(u,18) || substr(md5(new.id::text),1,6), d) on conflict (id) do nothing;
  end;
  return new;
end;
$$;
drop trigger if exists ps_on_auth_user_created on auth.users;
create trigger ps_on_auth_user_created after insert on auth.users for each row execute function public.ps_handle_new_user();

create or replace function public.ps_get_or_create_dm(p_other uuid) returns uuid
language plpgsql security definer set search_path = public, auth as $$
declare me uuid := auth.uid(); cid uuid;
begin
  if me is null then raise exception 'not_authenticated'; end if;
  if p_other is null or p_other = me then raise exception 'invalid_user'; end if;
  if not exists (select 1 from public.profiles where id = p_other) then raise exception 'user_not_found'; end if;
  -- Serialize direct-conversation creation for this user pair.
  perform pg_advisory_xact_lock(hashtextextended(least(me::text,p_other::text)||':'||greatest(me::text,p_other::text), 0));
  select c.id into cid from public.conversations c
  where exists (select 1 from public.conversation_members m where m.conversation_id=c.id and m.user_id=me)
    and exists (select 1 from public.conversation_members m where m.conversation_id=c.id and m.user_id=p_other)
    and (select count(*) from public.conversation_members m where m.conversation_id=c.id)=2
  order by c.created_at asc limit 1;
  if cid is null then
    insert into public.conversations (created_by) values (me) returning id into cid;
    insert into public.conversation_members (conversation_id,user_id) values (cid,me),(cid,p_other);
  end if;
  return cid;
end;
$$;

create or replace function public.ps_join_server(p_code text) returns uuid
language plpgsql security definer set search_path = public, auth as $$
declare me uuid := auth.uid(); inv public.server_invites%rowtype; got int;
begin
  if me is null then raise exception 'not_authenticated'; end if;
  select * into inv from public.server_invites where lower(code)=lower(trim(p_code)) for update;
  if not found then raise exception 'invite_not_found'; end if;
  if inv.expires_at is not null and inv.expires_at <= now() then raise exception 'invite_expired'; end if;
  if exists (select 1 from public.server_members where server_id=inv.server_id and user_id=me) then return inv.server_id; end if;
  if inv.max_uses is not null and coalesce(inv.uses,0)>=inv.max_uses then raise exception 'invite_exhausted'; end if;
  insert into public.server_members (server_id,user_id,role) values (inv.server_id,me,'member') on conflict do nothing;
  get diagnostics got = row_count;
  if got>0 then update public.server_invites set uses=coalesce(uses,0)+1 where id=inv.id; end if;
  return inv.server_id;
end;
$$;
revoke all on function public.ps_get_or_create_dm(uuid), public.ps_join_server(text) from public, anon;
grant execute on function public.ps_get_or_create_dm(uuid), public.ps_join_server(text) to authenticated;

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.comments enable row level security;
alter table public.post_likes enable row level security;
alter table public.follows enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;
alter table public.servers enable row level security;
alter table public.server_members enable row level security;
alter table public.server_invites enable row level security;

-- Drop only this migration's own policies to allow safe re-runs.
drop policy if exists butterfly_v1_profiles_select on public.profiles;
drop policy if exists butterfly_v1_profiles_insert on public.profiles;
drop policy if exists butterfly_v1_profiles_update on public.profiles;
drop policy if exists butterfly_v1_posts_select on public.posts;
drop policy if exists butterfly_v1_posts_insert on public.posts;
drop policy if exists butterfly_v1_posts_update on public.posts;
drop policy if exists butterfly_v1_posts_delete on public.posts;
drop policy if exists butterfly_v1_comments_select on public.comments;
drop policy if exists butterfly_v1_comments_insert on public.comments;
drop policy if exists butterfly_v1_comments_delete on public.comments;
drop policy if exists butterfly_v1_likes_select on public.post_likes;
drop policy if exists butterfly_v1_likes_insert on public.post_likes;
drop policy if exists butterfly_v1_likes_delete on public.post_likes;
drop policy if exists butterfly_v1_follows_select on public.follows;
drop policy if exists butterfly_v1_follows_insert on public.follows;
drop policy if exists butterfly_v1_follows_delete on public.follows;
drop policy if exists butterfly_v1_conversations_select on public.conversations;
drop policy if exists butterfly_v1_members_select on public.conversation_members;
drop policy if exists butterfly_v1_messages_select on public.messages;
drop policy if exists butterfly_v1_messages_insert on public.messages;
drop policy if exists butterfly_v1_messages_delete on public.messages;
drop policy if exists butterfly_v1_servers_select on public.servers;
drop policy if exists butterfly_v1_servers_insert on public.servers;
drop policy if exists butterfly_v1_servers_update on public.servers;
drop policy if exists butterfly_v1_servers_delete on public.servers;
drop policy if exists butterfly_v1_server_members_select on public.server_members;
drop policy if exists butterfly_v1_server_members_owner_insert on public.server_members;
drop policy if exists butterfly_v1_server_members_delete on public.server_members;
drop policy if exists butterfly_v1_invites_select on public.server_invites;
drop policy if exists butterfly_v1_invites_insert on public.server_invites;
drop policy if exists butterfly_v1_invites_delete on public.server_invites;

create policy butterfly_v1_profiles_select on public.profiles for select to authenticated using (true);
create policy butterfly_v1_profiles_insert on public.profiles for insert to authenticated with check (id=auth.uid());
create policy butterfly_v1_profiles_update on public.profiles for update to authenticated using (id=auth.uid()) with check (id=auth.uid());
create policy butterfly_v1_posts_select on public.posts for select to authenticated using (true);
create policy butterfly_v1_posts_insert on public.posts for insert to authenticated with check (author_id=auth.uid());
create policy butterfly_v1_posts_update on public.posts for update to authenticated using (author_id=auth.uid()) with check (author_id=auth.uid());
create policy butterfly_v1_posts_delete on public.posts for delete to authenticated using (author_id=auth.uid());
create policy butterfly_v1_comments_select on public.comments for select to authenticated using (true);
create policy butterfly_v1_comments_insert on public.comments for insert to authenticated with check (author_id=auth.uid());
create policy butterfly_v1_comments_delete on public.comments for delete to authenticated using (author_id=auth.uid() or exists(select 1 from public.posts p where p.id=post_id and p.author_id=auth.uid()));
create policy butterfly_v1_likes_select on public.post_likes for select to authenticated using (true);
create policy butterfly_v1_likes_insert on public.post_likes for insert to authenticated with check (user_id=auth.uid());
create policy butterfly_v1_likes_delete on public.post_likes for delete to authenticated using (user_id=auth.uid());
create policy butterfly_v1_follows_select on public.follows for select to authenticated using (true);
create policy butterfly_v1_follows_insert on public.follows for insert to authenticated with check (follower_id=auth.uid() and follower_id<>following_id);
create policy butterfly_v1_follows_delete on public.follows for delete to authenticated using (follower_id=auth.uid());
create policy butterfly_v1_conversations_select on public.conversations for select to authenticated using (public.ps_is_conv_member(id));
create policy butterfly_v1_members_select on public.conversation_members for select to authenticated using (public.ps_is_conv_member(conversation_id));
create policy butterfly_v1_messages_select on public.messages for select to authenticated using (public.ps_is_conv_member(conversation_id));
create policy butterfly_v1_messages_insert on public.messages for insert to authenticated with check (sender_id=auth.uid() and public.ps_is_conv_member(conversation_id));
create policy butterfly_v1_messages_delete on public.messages for delete to authenticated using (sender_id=auth.uid());
create policy butterfly_v1_servers_select on public.servers for select to authenticated using (owner_id=auth.uid() or public.ps_is_server_member(id));
create policy butterfly_v1_servers_insert on public.servers for insert to authenticated with check (owner_id=auth.uid());
create policy butterfly_v1_servers_update on public.servers for update to authenticated using (owner_id=auth.uid()) with check (owner_id=auth.uid());
create policy butterfly_v1_servers_delete on public.servers for delete to authenticated using (owner_id=auth.uid());
create policy butterfly_v1_server_members_select on public.server_members for select to authenticated using (public.ps_is_server_member(server_id));
create policy butterfly_v1_server_members_owner_insert on public.server_members for insert to authenticated with check (user_id=auth.uid() and role='owner' and exists(select 1 from public.servers s where s.id=server_id and s.owner_id=auth.uid()));
create policy butterfly_v1_server_members_delete on public.server_members for delete to authenticated using (user_id=auth.uid() or public.ps_is_server_admin(server_id));
create policy butterfly_v1_invites_select on public.server_invites for select to authenticated using (public.ps_is_server_member(server_id));
create policy butterfly_v1_invites_insert on public.server_invites for insert to authenticated with check (created_by=auth.uid() and public.ps_is_server_admin(server_id));
create policy butterfly_v1_invites_delete on public.server_invites for delete to authenticated using (public.ps_is_server_admin(server_id));

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types) values
('avatars','avatars',true,3145728,array['image/jpeg','image/png','image/webp']),
('posts','posts',true,5242880,array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public=excluded.public,file_size_limit=excluded.file_size_limit,allowed_mime_types=excluded.allowed_mime_types;

drop policy if exists butterfly_v1_storage_select on storage.objects;
drop policy if exists butterfly_v1_storage_insert on storage.objects;
drop policy if exists butterfly_v1_storage_update on storage.objects;
drop policy if exists butterfly_v1_storage_delete on storage.objects;
create policy butterfly_v1_storage_select on storage.objects for select to public using (bucket_id in ('avatars','posts'));
create policy butterfly_v1_storage_insert on storage.objects for insert to authenticated with check (bucket_id in ('avatars','posts') and (storage.foldername(name))[1]=auth.uid()::text);
create policy butterfly_v1_storage_update on storage.objects for update to authenticated using (bucket_id in ('avatars','posts') and (storage.foldername(name))[1]=auth.uid()::text) with check (bucket_id in ('avatars','posts') and (storage.foldername(name))[1]=auth.uid()::text);
create policy butterfly_v1_storage_delete on storage.objects for delete to authenticated using (bucket_id in ('avatars','posts') and (storage.foldername(name))[1]=auth.uid()::text);
