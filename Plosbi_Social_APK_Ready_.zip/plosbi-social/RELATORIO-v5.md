# Plosbi Social v5 — relatório curto

## Corrigido no código (só sintaxe verificada, sem build real)
- Mensagens: caixa de texto (textarea) e botão Enviar sempre visíveis na base da conversa.
- Enter envia no computador; no celular Enter quebra linha e o botão envia (Shift+Enter quebra linha).
- Celular: lista de conversas e conversa em telas separadas, com botão Voltar.
- Aviso quando não há internet; o texto não é perdido se o envio falhar.

- Foto de perfil: a regra antiga recusava fotos acima de 3 MB (fotos da câmera passam disso). Agora a imagem é recortada em quadrado, reduzida a 512 px e enviada em JPEG; a foto é salva no perfil na hora, com estado "Enviando..." e erros claros (bucket inexistente, tamanho, formato, sem internet).
- Imagens de publicação: reduzidas a 1600 px antes do envio (antes recusava acima de 5 MB).

## Ainda NÃO feito (próximas etapas)
Remoção da foto antiga do Storage, recuperação de senha, regra de 5 min para conta não confirmada,
auditoria de RLS no banco real, organização geral das telas, cores antigas isoladas.

## Para validar
1. `npm install` e `npm run build` (não rodei: sem acesso à internet aqui).
2. Duas contas, abrir conversa, enviar, recarregar a página, conferir que a mensagem persiste.
3. SQL: rodar apenas UM dos scripts (veja a mensagem do chat).
4. Foto: trocar a foto de perfil, recarregar a página e conferir que continua; testar também com uma foto da câmera.
- Servidores: o app cria o dono como membro com upsert (compatível com o gatilho novo do SQL).
