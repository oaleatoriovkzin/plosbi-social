import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.plosbi.social',
  appName: 'Plosbi Social',
  webDir: 'dist',
  bundledWebRuntime: false,
};

export default config;
