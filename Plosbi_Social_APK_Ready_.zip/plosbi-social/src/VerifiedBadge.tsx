export function VerifiedBadge({ size = 16 }: { size?: number }) {
  return (
    <svg className="verified-badge" width={size} height={size} viewBox="0 0 24 24" role="img" aria-label="Verificado" style={{ flex: 'none', verticalAlign: 'text-bottom' }}>
      <title>Verificado</title>
      <circle cx="12" cy="12" r="11" fill="#0a7cff" />
      <path d="M7 12.5l3.2 3.2L17 8.8" fill="none" stroke="#fff" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
