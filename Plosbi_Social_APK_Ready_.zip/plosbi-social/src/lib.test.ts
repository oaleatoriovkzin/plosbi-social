import { describe, expect, it } from 'vitest';
import { initials, timeAgo } from './lib';

describe('profile helpers', () => {
  it('creates initials from a display name', () => {
    expect(initials({ display_name: 'Kaique Oliveira', username: 'kaique' })).toBe('KO');
  });
  it('falls back to the username when no display name exists', () => {
    expect(initials({ username: 'blue.butterfly' })).toBe('BB');
  });
  it('uses a safe fallback for an empty profile', () => {
    expect(initials(null)).toBe('?');
  });
});

describe('relative timestamps', () => {
  it('labels a recent item as now', () => {
    expect(timeAgo(new Date(Date.now() - 10_000).toISOString())).toBe('agora');
  });
  it('formats minutes and hours', () => {
    expect(timeAgo(new Date(Date.now() - 5 * 60_000).toISOString())).toBe('5 min');
    expect(timeAgo(new Date(Date.now() - 2 * 60 * 60_000).toISOString())).toBe('2 h');
  });
});
