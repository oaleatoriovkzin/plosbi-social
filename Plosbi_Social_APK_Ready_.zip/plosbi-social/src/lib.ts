import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;
export const hasSupabaseConfig = Boolean(url && key && !url.includes('YOUR_PROJECT') && !key.includes('YOUR_SUPABASE'));
export const siteUrl = (import.meta.env.VITE_SITE_URL as string | undefined) || undefined;
export const supabase = hasSupabaseConfig ? createClient(url!, key!, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
}) : null;

export type Profile = { id: string; username: string; display_name: string | null; bio: string | null; avatar_url: string | null; cover_url?: string | null; is_verified?: boolean; created_at?: string };
export type Post = { id: string; author_id: string; content: string | null; media_url: string | null; created_at: string };
export type Comment = { id: string; post_id: string; author_id: string; content: string; created_at: string };
export type Message = { id: string; conversation_id: string; sender_id: string; content: string; created_at: string };

export function friendlyError(error: unknown): string {
  const message = error instanceof Error ? error.message : String(error ?? 'Erro desconhecido');
  if (/Invalid login credentials/i.test(message)) return 'E-mail ou senha incorretos.';
  if (/Email not confirmed/i.test(message)) return 'Confirme seu e-mail antes de entrar.';
  if (/User already registered/i.test(message)) return 'Este e-mail já tem uma conta. Tente entrar.';
  if (/Failed to fetch|fetch failed|NetworkError/i.test(message)) return 'Sem conexão com o Supabase. Confira a internet e as variáveis do .env.';
  if (/bucket not found/i.test(message)) return 'O armazenamento de imagens (bucket) não existe no Supabase. Rode o SQL da etapa 1.';
  if (/exceeded the maximum allowed size|payload too large/i.test(message)) return 'A imagem é maior que o limite permitido pelo bucket.';
  if (/mime type|not supported/i.test(message)) return 'Formato de imagem não permitido pelo bucket (use JPG, PNG ou WebP).';
  if (/row-level security|violates row-level security/i.test(message)) return 'O banco bloqueou esta ação pelas regras de segurança (RLS). Confira as políticas do Supabase.';
  return message;
}

export function initials(profile?: Partial<Profile> | null) {
  const label = profile?.display_name || profile?.username || '?';
  return label.split(/[\s._-]+/).filter(Boolean).slice(0, 2).map(s => s[0]?.toUpperCase()).join('') || '?';
}

export function timeAgo(date: string) {
  const seconds = Math.max(0, Math.floor((Date.now() - new Date(date).getTime()) / 1000));
  if (seconds < 60) return 'agora';
  if (seconds < 3600) return `${Math.floor(seconds / 60)} min`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)} h`;
  return `${Math.floor(seconds / 86400)} d`;
}

/** Reduz fotos grandes (câmera do celular) e converte para JPEG antes do upload. */
export async function resizeImage(file: File, max: number, square: boolean): Promise<Blob> {
  let bitmap: ImageBitmap;
  try { bitmap = await createImageBitmap(file); } catch { throw new Error('Não foi possível ler esta imagem. Tente outra foto em JPG, PNG ou WebP.'); }
  const side = Math.min(bitmap.width, bitmap.height);
  const sw = square ? side : bitmap.width, sh = square ? side : bitmap.height;
  const scale = Math.min(1, max / Math.max(sw, sh));
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(sw * scale); canvas.height = Math.round(sh * scale);
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Não foi possível processar a imagem neste aparelho.');
  ctx.drawImage(bitmap, (bitmap.width - sw) / 2, (bitmap.height - sh) / 2, sw, sh, 0, 0, canvas.width, canvas.height);
  bitmap.close();
  return await new Promise<Blob>((resolve, reject) => canvas.toBlob(b => b ? resolve(b) : reject(new Error('Falha ao converter a imagem.')), 'image/jpeg', 0.85));
}
