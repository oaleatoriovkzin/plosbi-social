# Plosbi Social — integração da Etapa 2

Esta versão do app foi alinhada ao contrato `etapa2_contrato_para_o_app.md` fornecido para a Etapa 2.

## Stories no app
- Consulta `stories` usando `content`, `image_url`, `bg_color`, `audience`, `created_at` e `expires_at`.
- Publicação de imagem usa o bucket existente `posts` e o caminho `${userId}/stories/${uuid}.jpg`.
- O app envia somente `author_id`, `content`, `image_url`, `bg_color` e `audience`; datas ficam a cargo dos padrões do banco.
- Visualização de story alheio registra `story_views` com `upsert` e conflito `story_id,viewer_id`, ignorando duplicados.
- Público padrão enviado pela interface atual: `followers`.

## Antes de publicar
1. Aplique no projeto Supabase correto os arquivos SQL oficiais `etapa2_parte*.sql` já revisados por você.
2. Confirme que a tabela `profiles` tem `cover_url` e `is_verified`, conforme os SQLs oficiais.
3. Configure as variáveis públicas `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY` e, se necessário, `VITE_SITE_URL`. Nunca coloque `service_role` no frontend.
4. Execute `npm install`, `npm run build` e teste login, publicação de post, Stories, curtidas, mensagens e perfil em uma cópia antes de publicar.

**Importante:** o SQL anterior `stories-profile-migration.sql` foi removido porque usava `media_url` e um bucket `stories`, incompatíveis com o contrato da Etapa 2. Use apenas os SQLs oficiais dessa etapa.
