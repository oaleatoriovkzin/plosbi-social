# Plosbi Social v6 — o que mudou (em cima do ZIP com GitHub)
FEITO: tema sólido na paleta da imagem (sem degradê/brilho/blur); borboleta azul e preta sólida; login estilo da imagem (GitHub + e-mail, mantém o login por GitHub); barra de baixo com 5 ícones (Início, Buscar, +, Mensagens, Perfil); stories de verdade (Stories.tsx: curtir 💙, quem viu, expiração, selo de verificado); removidos os repetidos: busca do topo, botão "Publicar" do cabeçalho, painel falso de "momentos", atalhos duplicados no topo (desktop).
NÃO FEITO: telas de Notificações/sino, Servidores no novo visual, Configurações no novo visual, Busca com abas, Salvos usando o banco (ainda usa o navegador), selo de verificado em posts/perfil, Reels.
NÃO TESTADO: só a sintaxe foi conferida. Sem build (npm) e sem teste no Supabase, porque o ambiente não tem internet. Rode `npm install && npm run build` e me mande qualquer erro.
SQL: etapa 2 e 3 (supabase/ da conversa) precisam estar rodadas — já estão.
