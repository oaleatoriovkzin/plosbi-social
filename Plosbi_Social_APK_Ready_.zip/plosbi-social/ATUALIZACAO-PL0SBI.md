# Atualização Plosbi Social

Esta atualização adiciona uma primeira implementação de Stories com imagem (expiração em 24 horas), visualizador de Stories, URL de capa no perfil e um indicador visual de verificação. Também ajusta o recorte das imagens para manter o conteúdo centralizado.

## Antes de publicar

1. Faça backup do banco Supabase e do ZIP atual.
2. Abra `supabase/stories-profile-migration.sql` e revise/aplique no SQL Editor do projeto correto. Ela cria `public.stories`, o bucket `stories`, políticas RLS e as colunas `cover_url` e `is_verified`.
3. O campo `is_verified` não pode ser alterado pelo usuário autenticado através do cliente; a migração instala um trigger para bloquear essa alteração. A administração pode alterar o selo no SQL Editor.
4. Configure as variáveis de ambiente a partir de `.env.example` no ambiente de build. O ZIP não inclui `.env`.
5. Execute `npm install`, `npm test` e `npm run build` antes de publicar.

## Limitações conhecidas

- Os Stories nesta primeira etapa são imagens, ficam disponíveis por 24 horas e podem ser abertos pelo círculo do autor. Não inclui vídeos, reações a Stories, visualização de quem assistiu ou agendamento automático para apagar linhas antigas; os Stories expirados são filtrados na consulta.
- A capa do perfil é configurada por URL no formulário de edição. Um upload de capa dedicado pode ser adicionado depois.
- O selo de verificação tem suporte de banco e exibição visual, mas a regra automática de 1.000 seguidores não foi ligada a um fluxo de aprovação. O selo deve ser concedido pela administração após revisão.
- A migração SQL ainda precisa ser aplicada no Supabase antes que Stories e capa funcionem. Não execute SQL em produção sem backup/revisão.

## Verificação desta entrega

A instalação de dependências foi tentada no ambiente de trabalho, mas não terminou dentro do limite disponível. Portanto, `npm test` e `npm run build` não foram confirmados e esta entrega não deve ser considerada compilada/testada até que esses comandos passem.
