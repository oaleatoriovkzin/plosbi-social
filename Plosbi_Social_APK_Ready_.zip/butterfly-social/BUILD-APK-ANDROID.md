# Como gerar o APK grátis do Plosbi Social

Este projeto contém um workflow do GitHub Actions para tentar gerar um APK de teste sem instalar Android Studio no celular.

1. Envie os arquivos e pastas deste projeto para um repositório GitHub seu. Envie o conteúdo da pasta `butterfly-social`, não a pasta externa que a contém.
2. Confirme que o branch principal se chama `main` ou `master`.
3. No GitHub, abra a aba **Actions** e escolha **Build Plosbi Social APK**. Se aparecer um aviso para habilitar Actions, habilite.
4. Abra a execução mais recente e espere terminar. Se ficar verde, abra a execução e baixe o artefato `plosbi-social-apk`.
5. Extraia o ZIP baixado; dentro estará `app-debug.apk`. No Android, só instale se reconhecer o arquivo e confiar nele.

Observações:
- A primeira compilação pode falhar se houver erros de TypeScript, dependências ou configuração. Nesse caso, abra a execução e veja a etapa vermelha; corrija o erro antes de tentar novamente.
- Este é um APK de teste (debug), não uma versão assinada para publicar na Play Store.
- O APK é apenas uma embalagem Android do app web. As funções online dependem da configuração correta do Supabase e das tabelas/políticas já existentes.
- Não coloque senhas, tokens privados nem a chave `service_role` no repositório. A chave anon/publicável do Supabase pode aparecer no frontend, mas as políticas RLS devem estar corretamente configuradas.
