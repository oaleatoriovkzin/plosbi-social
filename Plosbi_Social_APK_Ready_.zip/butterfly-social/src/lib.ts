import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;
export const hasSupabaseConfig = Boolean(url && key && !url.includes('YOUR_PROJECT') && !key.includes('YOUR_SUPABASE'));
export const supabase = hasSupabaseConfig ? createClient(url!, key!, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
}) : null;

export type Profile = { id: string; username: string; display_name: string | null; bio: string | null; avatar_url: string | null; created_at?: string };
export type Post = { id: string; author_id: string; content: string | null; media_url: string | null; created_at: string };
export type Comment = { id: string; post_id: string; author_id: string; content: string; created_at: string };
export type Message = { id: string; conversation_id: string; sender_id: string; content: string; created_at: string };

export function friendlyError(error: unknown): string {
  const message = error instanceof Error ? error.message : String(error ?? 'Erro desconhecido');
  if (/Invalid login credentials/i.test(message)) return 'E-mail ou senha incorretos.';
  if (/Email not confirmed/i.test(message)) return 'Confirme seu e-mail antes de entrar.';
  if (/User already registered/i.test(message)) return 'Este e-mail já tem uma conta. Tente entrar.';
  if (/Failed to fetch|fetch failed|NetworkError/i.test(message)) return 'Sem conexão com o Supabase. Confira a internet e as variáveis do .env.';
  if (/row-level security|violates row-level security/i.test(message)) return 'O banco bloqueou esta ação pelas regras de segurança (RLS). Confira as políticas do Supabase.';
  return message;
}

export function initials(profile?: Partial<Profile> | null) {
  const label = profile?.display_name || profile?.username || '?';
  return label.split(/[\s._-]+/).filter(Boolean).slice(0, 2).map(s => s[0]?.toUpperCase()).join('') || '?';
}

export function timeAgo(date: string) {
  const seconds = Math.max(0, Math.floor((Date.now() - new Date(date).getTime()) / 1000));
  if (seconds < 60) return 'agora';
  if (seconds < 3600) return `${Math.floor(seconds / 60)} min`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)} h`;
  return `${Math.floor(seconds / 86400)} d`;
}
