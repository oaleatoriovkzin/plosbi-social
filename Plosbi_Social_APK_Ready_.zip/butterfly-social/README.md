# Butterfly Social

Aplicação social web responsiva feita com React, TypeScript, Vite e Supabase, com identidade própria de borboleta azul. A interface foi projetada para desktop e celular e usa o esquema de tabelas `profiles`, `posts`, `post_likes`, `comments`, `follows`, `conversations`, `conversation_members`, `messages`, `servers`, `server_members` e `server_invites` que já existe no projeto Plosbi.

## O que está implementado

- Cadastro e login reais via Supabase Auth; sessão persistente e saída da conta.
- Feed online com publicações, upload de imagem para o bucket `posts`, curtidas e comentários.
- Pesquisa de publicações e perfis; seguir/deixar de seguir; perfis e grade de publicações.
- Mensagens privadas via RPC `ps_get_or_create_dm`, envio de mensagens, atualização em tempo real quando o Supabase Realtime estiver habilitado e indicador de digitação via Broadcast.
- Criação de servidores e convite por código via RPC `ps_join_server`.
- Personalização local: tema claro/escuro, cor de destaque, fonte e preferência de confirmação de leitura.
- Bem-estar digital: estimativa de tempo com a página aberta, limite diário, intervalo de pausa e modo silencioso local.
- Layout responsivo, estados vazios, mensagens de erro e carregamento.

## Requisitos

- Node.js 20 ou mais recente.
- Projeto Supabase existente.
- Tabelas públicas com as colunas indicadas no esquema do Plosbi.

## Instalação local

1. Extraia a pasta do projeto.
2. Copie `.env.example` para `.env`.
3. Confira `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY`. O arquivo de exemplo usa os valores públicos que já estavam na versão HTML enviada anteriormente. Se seu projeto Supabase for outro, substitua-os.
4. Instale as dependências e inicie:

   ```bash
   npm install
   npm run dev
   ```

5. Abra o endereço local que o Vite mostrar no terminal.
6. Para gerar a versão de produção:

   ```bash
   npm run build
   npm run preview
   ```

## Supabase

- O cliente usa somente a chave publicável/anon. **Nunca** coloque a chave `service_role` no frontend.
- O perfil básico precisa ser criado no cadastro. O arquivo `supabase/setup.sql` contém funções, políticas nomeadas do Butterfly e políticas do Storage para o esquema conhecido. Leia o arquivo antes de executar e faça um backup do projeto.
- As funções `ps_get_or_create_dm` e `ps_join_server` precisam existir para iniciar DMs e entrar por convite. Se o SQL delas não foi aplicado, essas ações mostrarão um erro em vez de falharem silenciosamente.
- O bucket `posts` precisa permitir upload e leitura pública das imagens de publicações; `avatars` é usado para fotos de perfil.
- Em **Supabase → Authentication → URL Configuration**, adicione os domínios locais e de produção permitidos.
- Para atualizações em tempo real, habilite Realtime para `posts`, `post_likes`, `comments` e `messages`.

## Limitações que devem ser conhecidas

- O contador de tempo mede minutos enquanto o app está aberto nesta aba/dispositivo; não é uma medição de sistema operacional nem sincroniza entre dispositivos.
- O intervalo de pausa e o modo silencioso são preferências locais; o modo silencioso permite configurar horário e silencia avisos comuns dentro dele. Notificações programadas com o navegador fechado exigiriam service worker/notificações e permissões extras.
- A opção de confirmação de leitura é somente uma preferência visual local. A tabela atual `messages` não tem campos de leitura; recibos reais exigem uma migração de banco e políticas específicas.
- Os fundos de conversa são personalizados localmente por conversa. Indicadores de digitação usam Supabase Realtime Broadcast e precisam de conectividade em tempo real habilitada.
- Stories, notificações push, salvamento de publicações, moderação e recuperação de senha precisam de implementação adicional para produção.
- A aplicação foi preparada para o esquema enviado, mas não é possível validar suas políticas RLS reais nem fazer login na sua conta a partir deste ambiente.

## Segurança

Não desative RLS para “fazer funcionar”. Se aparecer erro de RLS, revise a política da tabela indicada. Nunca publique `service_role`, senhas ou tokens privados em `.env` versionado.
