import { useState } from 'react';
import { Plus } from 'lucide-react';
import { supabase } from './lib';

// Contas guardadas neste aparelho (cada uma com o seu login). Trocar de conta não pede senha de novo.
const KEY = 'plosbi-accounts';
export type SavedAccount = { id: string; username: string; display_name: string | null; avatar_url: string | null; access_token: string; refresh_token: string };
type Say = (text: string, kind?: 'error' | 'success') => void;

export function loadAccounts(): SavedAccount[] {
  try { const v = JSON.parse(localStorage.getItem(KEY) || '[]'); return Array.isArray(v) ? v : []; } catch { return []; }
}
function saveAll(list: SavedAccount[]) { try { localStorage.setItem(KEY, JSON.stringify(list)); } catch { /* sem espaço: ignora */ } }
export function upsertAccount(a: SavedAccount) {
  const all = loadAccounts(); const at = all.findIndex(x => x.id === a.id);
  if (at >= 0) all[at] = a; else all.push(a);
  saveAll(all);
}
export function removeAccount(id: string) { saveAll(loadAccounts().filter(x => x.id !== id)); }

export async function switchTo(id: string): Promise<string | null> {
  const target = loadAccounts().find(x => x.id === id);
  if (!supabase || !target) return 'Conta não encontrada neste aparelho.';
  const { error } = await supabase.auth.setSession({ access_token: target.access_token, refresh_token: target.refresh_token });
  if (error) { removeAccount(id); return 'O login dessa conta expirou. Entre de novo para adicioná-la.'; }
  return null;
}

function Face({ a }: { a: SavedAccount }) {
  const n = (a.display_name || a.username || '?').slice(0, 1).toUpperCase();
  return a.avatar_url ? <img className="st-pic acc-face" src={a.avatar_url} alt="" /> : <span className="st-pic st-pic-empty acc-face">{n}</span>;
}

function List({ meId, notify }: { meId?: string; notify: Say }) {
  const [list, setList] = useState(loadAccounts());
  const [busy, setBusy] = useState<string | null>(null);
  async function go(id: string) {
    setBusy(id);
    const err = await switchTo(id);
    if (err) { notify(err, 'error'); setList(loadAccounts()); setBusy(null); return; }
    window.location.reload();
  }
  if (list.length === 0) return <p className="acc-empty">Nenhuma conta guardada ainda.</p>;
  return (
    <ul className="acc-list">
      {list.map(a => (
        <li key={a.id}>
          <button disabled={busy !== null || a.id === meId} onClick={() => void go(a.id)}>
            <Face a={a} />
            <span className="acc-name"><b>{a.display_name || a.username || 'Conta'}</b>{a.username && <small>@{a.username}</small>}</span>
            <span className="acc-tag">{a.id === meId ? 'Em uso' : busy === a.id ? 'Entrando…' : 'Entrar'}</span>
          </button>
        </li>
      ))}
    </ul>
  );
}

export function AccountsSheet({ meId, onClose, notify }: { meId: string; onClose: () => void; notify: Say }) {
  async function add() { if (supabase) await supabase.auth.signOut({ scope: 'local' }); }   // só sai deste aparelho; a conta atual continua guardada
  return (
    <div className="menu-sheet-backdrop" onClick={onClose}>
      <div className="menu-sheet" role="dialog" aria-label="Trocar de conta" onClick={e => e.stopPropagation()}>
        <h3 className="acc-title">Contas neste aparelho</h3>
        <List meId={meId} notify={notify} />
        <button className="acc-add" onClick={() => void add()}><Plus size={20} /> Adicionar outra conta</button>
      </div>
    </div>
  );
}

// Na tela de login: voltar para uma conta já guardada sem digitar senha
export function SavedAccounts({ notify }: { notify: Say }) {
  if (loadAccounts().length === 0) return null;
  return <div className="acc-saved"><p>Contas neste aparelho</p><List notify={notify} /></div>;
}
