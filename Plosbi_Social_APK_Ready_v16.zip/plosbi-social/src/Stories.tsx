import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Eye, ImagePlus, Plus, Trash2, X } from 'lucide-react';
import { supabase, resizeImage, timeAgo, friendlyError } from './lib';
import { VerifiedBadge } from './VerifiedBadge';
import './stories.css';

type Story = { id: string; author_id: string; content: string | null; image_url: string | null; bg_color: string; created_at: string };
type P = { id: string; username: string; display_name: string | null; avatar_url: string | null; is_verified: boolean };
type Say = (text: string, kind?: 'error' | 'success') => void;
const PCOLS = 'id,username,display_name,avatar_url,is_verified';
const nameOf = (p?: P) => p?.display_name || p?.username || 'Pessoa';

function Pic({ p, size = 56 }: { p?: P; size?: number }) {
  const box = { width: size, height: size };
  return p?.avatar_url
    ? <img className="st-pic" style={box} src={p.avatar_url} alt={nameOf(p)} />
    : <span className="st-pic st-pic-empty" style={box}>{nameOf(p).slice(0, 1).toUpperCase()}</span>;
}

function Name({ p }: { p?: P }) {
  return <span className="st-name"><span>{nameOf(p)}</span>{p?.is_verified && <VerifiedBadge size={14} />}</span>;
}

export function StoriesBar({ meId, notify }: { meId: string; notify?: Say }) {
  const [stories, setStories] = useState<Story[]>([]);
  const [profiles, setProfiles] = useState<Record<string, P>>({});
  const [seen, setSeen] = useState<Set<string>>(new Set());
  const [liked, setLiked] = useState<Set<string>>(new Set());
  const [open, setOpen] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const notifyRef = useRef(notify); notifyRef.current = notify;
  const say: Say = (t, k = 'error') => notifyRef.current?.(t, k);

  const load = useCallback(async () => {
    if (!supabase) return;
    const res = await supabase.from('stories').select('id,author_id,content,image_url,bg_color,created_at')
      .gt('expires_at', new Date().toISOString()).order('created_at', { ascending: true });
    if (res.error) { notifyRef.current?.(friendlyError(res.error), 'error'); return; }
    const list = (res.data ?? []) as Story[];
    const ids = Array.from(new Set([meId, ...list.map(s => s.author_id)]));
    const [pr, sv, lk] = await Promise.all([
      supabase.from('profiles').select(PCOLS).in('id', ids),
      supabase.from('story_views').select('story_id').eq('viewer_id', meId),
      supabase.from('story_likes').select('story_id').eq('user_id', meId)
    ]);
    setStories(list);
    setProfiles(Object.fromEntries(((pr.data ?? []) as P[]).map(p => [p.id, p])));
    setSeen(new Set(((sv.data ?? []) as { story_id: string }[]).map(r => r.story_id)));
    setLiked(new Set(((lk.data ?? []) as { story_id: string }[]).map(r => r.story_id)));
  }, [meId]);
  useEffect(() => { void load(); }, [load]);

  const mine = stories.filter(s => s.author_id === meId);
  const groups = useMemo(() => {
    const m = new Map<string, Story[]>();
    stories.filter(s => s.author_id !== meId).forEach(s => m.set(s.author_id, [...(m.get(s.author_id) ?? []), s]));
    return Array.from(m.entries())
      .map(([author, list]) => ({ author, list, unseen: list.some(s => !seen.has(s.id)) }))
      .sort((a, b) => Number(b.unseen) - Number(a.unseen));
  }, [stories, seen, meId]);

  async function markSeen(id: string) {
    if (!supabase || seen.has(id)) return;
    setSeen(prev => new Set(prev).add(id));
    await supabase.from('story_views').upsert({ story_id: id, viewer_id: meId }, { onConflict: 'story_id,viewer_id', ignoreDuplicates: true });
  }

  async function toggleLike(id: string) {
    if (!supabase) return;
    const had = liked.has(id);
    const flip = (on: boolean) => setLiked(prev => { const n = new Set(prev); if (on) n.add(id); else n.delete(id); return n; });
    flip(!had);
    const { error } = had
      ? await supabase.from('story_likes').delete().eq('story_id', id).eq('user_id', meId)
      : await supabase.from('story_likes').insert({ story_id: id, user_id: meId });
    if (error) { flip(had); say(friendlyError(error)); }
  }

  async function removeStory(id: string) {
    if (!supabase) return;
    const { error } = await supabase.from('stories').delete().eq('id', id).eq('author_id', meId);
    if (error) { say(friendlyError(error)); return; }
    setStories(prev => prev.filter(s => s.id !== id));
  }

  const openList = open === meId ? mine : groups.find(g => g.author === open)?.list ?? [];
  const openAuthor = open ? profiles[open] : undefined;

  return (
    <>
      <div className="st-bar" aria-label="Stories">
        <div className="st-item">
          <button className={`st-ring ${mine.length ? '' : 'st-ring-off'}`} aria-label={mine.length ? 'Ver seu story' : 'Criar story'}
            onClick={() => (mine.length ? setOpen(meId) : setCreating(true))}><Pic p={profiles[meId]} size={58} /></button>
          <button className="st-plus" aria-label="Novo story" onClick={() => setCreating(true)}><Plus size={16} /></button>
          <span className="st-name"><span>Seu story</span></span>
        </div>
        {groups.map(g => (
          <div className="st-item" key={g.author}>
            <button className={`st-ring ${g.unseen ? '' : 'st-ring-seen'}`} aria-label={`Ver story de ${nameOf(profiles[g.author])}`}
              onClick={() => setOpen(g.author)}><Pic p={profiles[g.author]} size={58} /></button>
            <Name p={profiles[g.author]} />
          </div>
        ))}
      </div>

      {open && openList.length > 0 && (
        <StoryViewer key={open} list={openList} author={openAuthor} own={open === meId} liked={liked}
          onClose={() => setOpen(null)} onSeen={markSeen} onLike={toggleLike} onDelete={removeStory} say={say} />
      )}
      {creating && (
        <CreateStory meId={meId} say={say} onClose={() => setCreating(false)}
          onCreated={() => { setCreating(false); void load(); say('Story publicado.', 'success'); }} />
      )}
    </>
  );
}

function StoryViewer({ list, author, own, liked, onClose, onSeen, onLike, onDelete, say }: {
  list: Story[]; author?: P; own: boolean; liked: Set<string>; onClose: () => void;
  onSeen: (id: string) => void; onLike: (id: string) => void; onDelete: (id: string) => Promise<void>; say: Say;
}) {
  const [i, setI] = useState(0);
  const [panel, setPanel] = useState(false);
  const [held, setHeld] = useState(false);
  const [fit, setFit] = useState<'cover' | 'contain'>('contain');
  const remain = useRef(5000); const startedAt = useRef(0); const holdAt = useRef(0);
  const [viewers, setViewers] = useState<{ p: P; liked: boolean }[] | null>(null);
  const s = list[Math.min(i, list.length - 1)];

  const next = () => (i + 1 >= list.length ? onClose() : setI(i + 1));
  useEffect(() => { if (!own) onSeen(s.id); }, [s.id]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { remain.current = 5000; }, [i]);
  useEffect(() => {
    if (panel || held) return;
    startedAt.current = Date.now();
    const t = setTimeout(next, remain.current);
    return () => { clearTimeout(t); remain.current = Math.max(0, remain.current - (Date.now() - startedAt.current)); };
  }, [i, panel, held]); // eslint-disable-line react-hooks/exhaustive-deps
  const hold = { onPointerDown: () => { holdAt.current = Date.now(); setHeld(true); }, onPointerUp: () => setHeld(false), onPointerCancel: () => setHeld(false), onPointerLeave: () => setHeld(false) };
  const tapped = (fn: () => void) => { if (Date.now() - holdAt.current > 250) return; fn(); };

  async function openPanel() {
    if (!supabase) return;
    setPanel(true); setViewers(null);
    const [v, l] = await Promise.all([
      supabase.from('story_views').select('viewer_id').eq('story_id', s.id).order('viewed_at', { ascending: false }),
      supabase.from('story_likes').select('user_id').eq('story_id', s.id)
    ]);
    if (v.error || l.error) { say(friendlyError(v.error ?? l.error)); setViewers([]); return; }
    const likers = new Set(((l.data ?? []) as { user_id: string }[]).map(r => r.user_id));
    const ids = ((v.data ?? []) as { viewer_id: string }[]).map(r => r.viewer_id);
    const pr = ids.length ? await supabase.from('profiles').select(PCOLS).in('id', ids) : { data: [] as P[] };
    const map = new Map(((pr.data ?? []) as P[]).map(p => [p.id, p]));
    setViewers(ids.map(id => map.get(id)).filter((p): p is P => !!p).map(p => ({ p, liked: likers.has(p.id) })));
  }

  async function remove() {
    await onDelete(s.id);
    if (list.length <= 1) onClose(); else setI(Math.max(0, i - 1));
  }

  return (
    <div className={`st-overlay ${panel || held ? 'st-paused' : ''}`} role="dialog" aria-label="Story" onContextMenu={e => e.preventDefault()}>
      <div className="st-progress">
        {list.map((x, k) => <span key={x.id} className={`st-seg ${k < i ? 'st-done' : k === i ? 'st-now' : ''}`} />)}
      </div>
      <div className="st-head">
        <Pic p={author} size={40} />
        <div className="st-who"><strong>{nameOf(author)}{author?.is_verified && <VerifiedBadge size={15} />}</strong><small>{timeAgo(s.created_at)}</small></div>
        <button className="st-close" aria-label="Fechar" onClick={onClose}><X size={22} /></button>
      </div>
      <div className="st-body">
        {s.image_url
          ? <><img className="st-img" src={s.image_url} alt="" style={{ objectFit: fit }} onLoad={e => { const im = e.currentTarget; const box = im.parentElement?.getBoundingClientRect(); if (!box || !im.naturalHeight) return; const r = im.naturalWidth / im.naturalHeight, f = box.width / box.height; setFit(Math.abs(r - f) / f < 0.2 ? 'cover' : 'contain'); }} />{s.content && <div className="st-caption">{s.content}</div>}</>
          : <div className="st-text" style={{ background: s.bg_color }}>{s.content}</div>}
        <button className="st-tap st-prev" aria-label="Anterior" {...hold} onClick={() => tapped(() => setI(Math.max(0, i - 1)))} />
        <button className="st-tap st-next" aria-label="Próximo" {...hold} onClick={() => tapped(next)} />
      </div>
      <div className="st-foot">
        {own ? (
          <>
            <button className="st-btn" onClick={() => void openPanel()}><Eye size={20} /> Quem viu</button>
            <button className="st-btn st-btn-danger" aria-label="Apagar story" onClick={() => void remove()}><Trash2 size={20} /> Apagar</button>
          </>
        ) : (
          <button className={`st-btn ${liked.has(s.id) ? 'st-btn-on' : ''}`} aria-pressed={liked.has(s.id)} onClick={() => onLike(s.id)}>
            <span aria-hidden>💙</span> {liked.has(s.id) ? 'Curtido' : 'Curtir'}
          </button>
        )}
      </div>
      {panel && (
        <div className="st-sheet">
          <div className="st-row"><h3 style={{ flex: 1 }}>Visualizações{viewers ? ` (${viewers.length})` : ''}</h3>
            <button className="st-close" aria-label="Fechar lista" onClick={() => setPanel(false)}><X size={20} /></button></div>
          {viewers === null && <div className="st-empty">Carregando…</div>}
          {viewers?.length === 0 && <div className="st-empty">Ninguém viu ainda.</div>}
          {viewers?.map(v => (
            <div className="st-row" key={v.p.id}>
              <span className="st-avatar-wrap"><Pic p={v.p} size={44} />{v.liked && <span className="st-heart" aria-label="Curtiu">💙</span>}</span>
              <span className="st-who">{nameOf(v.p)}{v.p.is_verified && <VerifiedBadge size={14} />}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function CreateStory({ meId, say, onClose, onCreated }: { meId: string; say: Say; onClose: () => void; onCreated: () => void }) {
  const [text, setText] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState('');
  const [audience, setAudience] = useState<'followers' | 'everyone'>('followers');
  const [busy, setBusy] = useState(false);
  useEffect(() => () => { if (preview) URL.revokeObjectURL(preview); }, [preview]);

  function pick(f: File | undefined) {
    if (!f) return;
    setFile(f); setPreview(URL.createObjectURL(f));
  }

  async function publish() {
    if (!supabase || busy || (!text.trim() && !file)) return;
    setBusy(true);
    try {
      let image_url: string | null = null;
      if (file) {
        const path = `${meId}/stories/${crypto.randomUUID()}.jpg`;
        const up = await supabase.storage.from('posts').upload(path, await resizeImage(file, 1600, false), { upsert: false, contentType: 'image/jpeg' });
        if (up.error) throw up.error;
        image_url = supabase.storage.from('posts').getPublicUrl(path).data.publicUrl;
      }
      const { error } = await supabase.from('stories').insert({ author_id: meId, content: text.trim() || null, image_url, audience });
      if (error) throw error;
      onCreated();
    } catch (e) { say(friendlyError(e)); } finally { setBusy(false); }
  }

  return (
    <div className="st-overlay" role="dialog" aria-label="Novo story">
      <div className="st-head"><strong style={{ flex: 1 }}>Novo story</strong>
        <button className="st-close" aria-label="Cancelar" onClick={onClose}><X size={22} /></button></div>
      <div className="st-form">
        {preview && <img src={preview} alt="Prévia" />}
        <textarea value={text} maxLength={500} placeholder="O que você quer compartilhar?" onChange={e => setText(e.target.value)} />
        <label className="st-btn" style={{ justifyContent: 'center' }}><ImagePlus size={20} /> {file ? 'Trocar imagem' : 'Adicionar imagem'}
          <input type="file" accept="image/*" hidden onChange={e => pick(e.target.files?.[0])} /></label>
        <select value={audience} aria-label="Quem pode ver" onChange={e => setAudience(e.target.value as 'followers' | 'everyone')}>
          <option value="followers">Quem me segue</option><option value="everyone">Todos</option>
        </select>
        <button className="st-btn st-btn-on" style={{ justifyContent: 'center' }} disabled={busy || (!text.trim() && !file)} onClick={() => void publish()}>
          {busy ? 'Publicando…' : 'Publicar story'}
        </button>
      </div>
    </div>
  );
}
