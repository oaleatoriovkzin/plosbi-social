# Plosbi Social v6 — o que mudou (em cima do ZIP com GitHub)
FEITO: tema sólido na paleta da imagem (sem degradê/brilho/blur); borboleta azul e preta sólida; login estilo da imagem (GitHub + e-mail, mantém o login por GitHub); barra de baixo com 5 ícones (Início, Buscar, +, Mensagens, Perfil); stories de verdade (Stories.tsx: curtir 💙, quem viu, expiração, selo de verificado); removidos os repetidos: busca do topo, botão "Publicar" do cabeçalho, painel falso de "momentos", atalhos duplicados no topo (desktop).
NÃO FEITO: telas de Notificações/sino, Servidores no novo visual, Configurações no novo visual, Busca com abas, Salvos usando o banco (ainda usa o navegador), selo de verificado em posts/perfil, Reels.
NÃO TESTADO: só a sintaxe foi conferida. Sem build (npm) e sem teste no Supabase, porque o ambiente não tem internet. Rode `npm install && npm run build` e me mande qualquer erro.
SQL: etapa 2 e 3 (supabase/ da conversa) precisam estar rodadas — já estão.

# v7 — login do GitHub dentro do APK
Antes: o botão do GitHub mandava o login voltar para o SITE (https://...github.io), então o APK virava Chrome e a sessão ficava no Chrome.
Agora (só no APK): abre o navegador do sistema e volta para o app por link direto `com.plosbi.social://auth-callback`; a sessão é criada dentro do app. No site (Chrome) nada muda.
Precisa de 3 coisas fora do código: (1) plugins @capacitor/app e @capacitor/browser (já no package.json); (2) o workflow do APK inserir o intent-filter no AndroidManifest; (3) `com.plosbi.social://auth-callback` nos Redirect URLs do Supabase.
NÃO TESTADO: só sintaxe. Sem build nem teste em aparelho.

# v8 — Mensagens só com quem já tem conversa
Antes: a lista da aba Mensagens mostrava TODOS os usuários cadastrados (não eram conversas; as mensagens em si já eram protegidas pelo banco).
Agora: a lista mostra só quem já tem conversa com você. Ao digitar na busca, aparecem todos, para iniciar uma conversa nova.
NÃO TESTADO: só sintaxe. Sem build nem teste no aparelho.

# v9 — prévia e bolinha de mensagens não lidas
Lista de Mensagens: última mensagem cortada com "…", ordenada pela mais recente, e bolinha na cor de acento do tema quando há mensagem nova. Bolinha também no ícone de Mensagens da barra de baixo.
Precisa rodar supabase/etapa5_nao_lidas.sql. Sem rodar, a prévia funciona, mas a bolinha não aparece (o app não quebra).
NÃO TESTADO: só sintaxe. Sem build nem teste no aparelho.

# v10 — correções
Story: a imagem não cobre mais o botão Curtir; 💙 pequeno sobre a foto de quem curtiu. Selo de verificado no perfil, nos posts e na lista de Mensagens (o app agora carrega is_verified). Menu do perfil (três barrinhas): Configurações, Bem-estar e Sair saíram do topo. Bio mantém quebras de linha. Seletor de imagem aceita qualquer imagem (image/*).
NÃO TESTADO: só sintaxe. Causa do problema do "PNG maiúsculo" é provável, não confirmada.

# v11 — tela de comentários
Clicar em comentários abre uma tela própria: foto e nome de quem comentou, selo, 💙 quando quem publicou curtiu o comentário, curtir / não curtir com contagem, responder (uma camada de respostas), apagar (autor do comentário e dono do post), fixar (só o dono do post, um por post). Animações: coração/polegar com "pop", comentário que encolhe ao apagar, avião no botão de enviar (respeitam "reduzir movimento" do aparelho).
Precisa rodar supabase/etapa6_comentarios.sql. Sem rodar, o app continua comentando, mas curtir, responder e fixar não funcionam.
NÃO TESTADO: só sintaxe. Sem build nem teste no aparelho.
NÃO FEITO ainda: compartilhar com pessoa/outros apps, salvar foto, animações dos outros botões da referência, notificações, fundo do perfil, links.

# v12 — compartilhar e salvar foto
Botão Compartilhar abre uma folha com: enviar para uma pessoa (vira mensagem na conversa, com texto e link), outros apps (menu de compartilhar do Android/navegador), copiar texto e salvar foto (com animação). No APK, "salvar foto" abre o menu do Android para você escolher salvar; no navegador baixa o arquivo.
Novos plugins (já no package.json): @capacitor/share e @capacitor/filesystem. Não precisa de SQL novo.
NÃO TESTADO: só sintaxe. O link enviado é o da imagem (ou do site), não abre o post dentro do app.

# v13 — notificações, fundo do perfil, links, validação de imagem
Notificações: sino no topo com bolinha (cor do tema) e tela com abas Todas / Curtidas / Comentários / Seguidores; abre ao tocar; marca como lidas depois de 1,5 s. Fundo do perfil: foto ou GIF até 5 MB (GIF vai sem reduzir). Links no perfil (até 3). Validação de imagem agora olha o tipo OU a extensão em maiúsculas/minúsculas (causa provável do "PNG só maiúsculo": o código exigia file.type exato).
Precisa rodar supabase/etapa7_links_do_perfil.sql (links). Sem rodar, tudo funciona, menos salvar links.
NÃO TESTADO: só sintaxe.

# v14 — links clicáveis, enquadramento, política de privacidade
Endereços (https://… ou www.…) em posts, comentários, mensagens e bio viram links que funcionam (no APK abrem no navegador). Foto do feed preenche a largura; foto de story em quadro 9:16. Configurações → Privacidade → Política de privacidade (RASCUNHO, revisar antes de divulgar). Sem SQL novo.
NÃO TESTADO: só sintaxe.

# v15 — conta privada (opção A: seguir vira pedido)
Configurações → Privacidade → "Conta privada". Em conta privada, o botão vira "Solicitar" / "Solicitado"; quem recebe vê "pediu para seguir você" em Notificações com Aprovar / Recusar. Publicações, comentários, curtidas e stories de conta privada só aparecem para o dono e quem segue. Quem já seguia continua seguindo. Se a conta voltar a ser pública, os pedidos viram seguidores.
Precisa rodar supabase/etapa8_conta_privada.sql (depois da etapa 7). Sem rodar, o app funciona como antes (a chave de privacidade mostra erro).
LIMITE: imagens ficam em buckets públicos; quem tiver o link exato de uma foto ainda abre. NÃO TESTADO: só sintaxe.

# v16 — correções + trocar de conta
Stories: segurar o dedo pausa a barrinha (e retoma de onde parou); a foto aparece inteira (sem cortar), e só preenche a tela quando o formato já é quase igual. Faixa preta do topo no APK: a barra de status agora acompanha o tema (plugin @capacitor/status-bar). Seguir conta privada: depois de aprovado o botão vira "Seguindo" (o app atualiza ao voltar para o app e a cada 15 s enquanto há pedido pendente). Envio de foto de perfil/fundo: leitura da imagem com plano B, tipo de arquivo desconhecido não bloqueia, e a mensagem de erro agora diz o motivo real ("Foto de perfil: …" / "Fundo do perfil: …"). Trocar de conta: perfil → três barrinhas → Trocar de conta / Adicionar outra conta; na tela de login aparecem as contas guardadas.
Sem SQL novo. NÃO TESTADO: só sintaxe. Salvos e tema são do aparelho, não da conta.
